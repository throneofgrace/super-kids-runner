import React from 'react';
import {
  Play,
  User,
  Globe,
  Award,
  Settings,
  Gift,
  Coins,
  Trophy,
  Flame,
} from 'lucide-react';
import { CharacterConfig, Mission, PlayerStats, WorldConfig } from '../game/types';
import { checkDailyReward } from '../game/storage';

interface TitleScreenProps {
  stats: PlayerStats;
  currentWorld: WorldConfig;
  currentCharacter: CharacterConfig;
  missions: Mission[];
  onPlay: () => void;
  onOpenCharacters: () => void;
  onOpenWorlds: () => void;
  onOpenMissions: () => void;
  onOpenSettings: () => void;
  onClaimDaily: () => void;
  onOpenInstall: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  stats,
  currentWorld,
  currentCharacter,
  missions,
  onPlay,
  onOpenCharacters,
  onOpenWorlds,
  onOpenMissions,
  onOpenSettings,
  onClaimDaily,
  onOpenInstall,
}) => {
  const daily = checkDailyReward();
  const uncompletedClaimable = missions.filter((m) => m.completed).length;

  return (
    <div className="absolute inset-0 pointer-events-none z-20 flex flex-col justify-between p-4 md:p-8 select-none">
      {/* Top Bar: Coin Balance & High Score */}
      <div className="flex items-center justify-between w-full">
        {/* Left: Total Coins Balance */}
        <div className="flex items-center gap-2">
          <div className="bg-gradient-to-r from-amber-500 to-yellow-400 border-2 border-yellow-200 rounded-2xl px-4 py-2 shadow-xl flex items-center gap-2">
            <Coins className="w-6 h-6 text-amber-950 fill-amber-950" />
            <span className="text-amber-950 font-black text-lg md:text-2xl tabular-nums">
              {stats.coins.toLocaleString()}
            </span>
          </div>

          {daily.available && (
            <button
              onClick={onClaimDaily}
              className="pointer-events-auto bg-pink-500 hover:bg-pink-400 active:scale-95 border-2 border-pink-200 rounded-2xl px-3 py-2 text-white font-black text-xs md:text-sm shadow-xl flex items-center gap-1.5 animate-bounce"
            >
              <Gift className="w-4 h-4 fill-white" />
              <span>Free Gift!</span>
            </button>
          )}
        </div>

        {/* Right: Install, High Score & Settings */}
        <div className="flex items-center gap-2">
          {/* Install Button */}
          <button
            onClick={onOpenInstall}
            className="pointer-events-auto bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 active:scale-95 text-white border-2 border-emerald-300 rounded-2xl px-3 py-1.5 shadow-xl flex items-center gap-1.5 text-xs md:text-sm font-black transition-all"
            title="Install on Phone"
          >
            <span className="text-base">📲</span>
            <span className="hidden sm:inline">Install Game</span>
            <span className="sm:hidden">Install</span>
          </button>

          <div className="bg-slate-900/85 border-2 border-amber-400/80 rounded-2xl px-3 md:px-4 py-2 shadow-xl flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400 fill-amber-400" />
            <div>
              <div className="text-[10px] text-amber-300 font-black uppercase leading-none">
                Best
              </div>
              <div className="text-white font-black text-sm md:text-xl tabular-nums leading-none mt-0.5">
                {stats.highScore.toLocaleString()}
              </div>
            </div>
          </div>

          <button
            onClick={onOpenSettings}
            className="pointer-events-auto bg-slate-900/90 hover:bg-slate-800 active:scale-95 text-white border-2 border-slate-600 rounded-2xl p-2.5 shadow-xl transition-all"
            title="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Centerpiece Hero Title Lockup & Big PLAY CTA */}
      <div className="flex flex-col items-center justify-center my-auto text-center">
        {/* Bespoke Colorful SVG Title Badge */}
        <div className="mb-2 md:mb-4 max-w-lg w-full px-2">
          <div className="inline-block bg-gradient-to-r from-red-500 via-amber-400 to-yellow-300 text-slate-950 font-black text-xs md:text-sm uppercase tracking-widest px-4 py-1 rounded-full shadow-lg border-2 border-white mb-2">
            Kids 3D Endless Adventure
          </div>
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 via-amber-400 to-orange-500 drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)] tracking-tight uppercase leading-tight font-sans">
            SUPER KIDS
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-sky-400 to-emerald-400">
              RUNNER 3D
            </span>
          </h1>

          <div className="flex items-center justify-center gap-2 mt-2">
            <span className="bg-slate-900/80 text-amber-300 font-extrabold text-xs md:text-sm px-3 py-1 rounded-xl border border-amber-400/50 flex items-center gap-1.5 shadow">
              <Globe className="w-4 h-4 text-emerald-400" /> {currentWorld.name}
            </span>
            <span className="bg-slate-900/80 text-sky-300 font-extrabold text-xs md:text-sm px-3 py-1 rounded-xl border border-sky-400/50 flex items-center gap-1.5 shadow">
              <User className="w-4 h-4 text-amber-400" /> {currentCharacter.name} ({currentCharacter.title})
            </span>
          </div>
        </div>

        {/* Big Juicy PLAY Button */}
        <button
          onClick={onPlay}
          className="pointer-events-auto group mt-4 relative bg-gradient-to-b from-emerald-400 to-emerald-600 hover:from-emerald-300 hover:to-emerald-500 active:from-emerald-600 active:to-emerald-700 border-4 border-emerald-200 rounded-3xl py-4 px-12 md:px-16 shadow-[0_12px_32px_rgba(16,185,129,0.5)] transform active:translate-y-1 hover:scale-105 transition-all flex items-center gap-3 cursor-pointer"
        >
          <Play className="w-8 h-8 md:w-10 md:h-10 text-white fill-white group-hover:scale-110 transition-transform" />
          <span className="text-white font-black text-2xl md:text-4xl tracking-wider uppercase drop-shadow-md">
            PLAY NOW!
          </span>
        </button>

        <div className="mt-2.5 text-xs text-white/80 font-bold bg-slate-900/60 px-4 py-1 rounded-full border border-white/10 shadow">
          Press <span className="text-amber-400">Space</span> or <span className="text-amber-400">Enter</span> to Start
        </div>
      </div>

      {/* Ergonomic Bottom Navigation Dock */}
      <div className="pointer-events-auto w-full max-w-xl mx-auto bg-slate-900/90 border-2 border-slate-700/80 rounded-3xl p-2.5 md:p-3 shadow-2xl flex items-center justify-around gap-2">
        {/* Characters Button */}
        <button
          onClick={onOpenCharacters}
          className="flex-1 py-2 px-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-white flex flex-col items-center gap-1 transition-all border border-slate-700"
        >
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <User className="w-5 h-5" />
          </div>
          <span className="text-[11px] md:text-xs font-black uppercase tracking-wide">
            Heroes
          </span>
        </button>

        {/* Worlds Button */}
        <button
          onClick={onOpenWorlds}
          className="flex-1 py-2 px-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-white flex flex-col items-center gap-1 transition-all border border-slate-700"
        >
          <div className="w-8 h-8 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center">
            <Globe className="w-5 h-5" />
          </div>
          <span className="text-[11px] md:text-xs font-black uppercase tracking-wide">
            Worlds
          </span>
        </button>

        {/* Missions Button */}
        <button
          onClick={onOpenMissions}
          className="flex-1 py-2 px-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-white flex flex-col items-center gap-1 transition-all border border-slate-700 relative"
        >
          {uncompletedClaimable > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-pink-500 text-white font-black text-[10px] flex items-center justify-center border-2 border-slate-900">
              {uncompletedClaimable}
            </span>
          )}
          <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
          <span className="text-[11px] md:text-xs font-black uppercase tracking-wide">
            Quests
          </span>
        </button>

        {/* Daily Gift Button */}
        <button
          onClick={onClaimDaily}
          className={`flex-1 py-2 px-2.5 rounded-2xl flex flex-col items-center gap-1 transition-all border ${
            daily.available
              ? 'bg-gradient-to-b from-pink-600 to-rose-700 text-white border-pink-400 animate-pulse'
              : 'bg-slate-800 text-slate-400 border-slate-700'
          }`}
        >
          <div className="w-8 h-8 rounded-xl bg-white/20 text-white flex items-center justify-center">
            <Gift className="w-5 h-5" />
          </div>
          <span className="text-[11px] md:text-xs font-black uppercase tracking-wide">
            {daily.available ? 'Gift!' : 'Daily'}
          </span>
        </button>
      </div>
    </div>
  );
};
