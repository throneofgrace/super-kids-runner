import React from 'react';
import { X, Check, Lock, Coins, Sparkles } from 'lucide-react';
import { CharacterConfig } from '../game/types';
import { CHARACTERS } from '../game/worldConfig';

interface CharacterSelectModalProps {
  selectedId: string;
  unlockedIds: string[];
  coins: number;
  onSelect: (id: string) => void;
  onUnlock: (character: CharacterConfig) => void;
  onClose: () => void;
}

export const CharacterSelectModal: React.FC<CharacterSelectModalProps> = ({
  selectedId,
  unlockedIds,
  coins,
  onSelect,
  onUnlock,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/80 z-50 flex items-center justify-center p-3 md:p-6 select-none overflow-y-auto">
      <div className="bg-slate-900 border-4 border-amber-400 rounded-3xl p-5 md:p-7 max-w-2xl w-full shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-700/80 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-2xl">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl md:text-3xl font-black text-amber-400 uppercase tracking-wide">
                Choose Your Hero
              </h2>
              <p className="text-slate-400 text-xs md:text-sm">
                Unlock cute kid runners with special adventure perks!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-r from-amber-500 to-yellow-400 rounded-xl px-3 py-1 flex items-center gap-1.5 shadow">
              <Coins className="w-4 h-4 text-amber-950 fill-amber-950" />
              <span className="text-amber-950 font-black text-sm tabular-nums">
                {coins}
              </span>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Character Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 md:gap-4 max-h-[65vh] overflow-y-auto pr-1">
          {CHARACTERS.map((char) => {
            const isUnlocked = unlockedIds.includes(char.id);
            const isSelected = selectedId === char.id;
            const canAfford = coins >= char.cost;

            return (
              <div
                key={char.id}
                className={`flex flex-col justify-between rounded-2xl p-4 border-2 transition-all ${
                  isSelected
                    ? 'bg-amber-500/15 border-amber-400 shadow-[0_0_20px_rgba(251,191,36,0.25)]'
                    : isUnlocked
                    ? 'bg-slate-800/80 border-slate-700 hover:border-slate-500'
                    : 'bg-slate-800/40 border-slate-800 opacity-90'
                }`}
              >
                <div>
                  {/* Avatar Icon Badge */}
                  <div className="flex items-center justify-between mb-3">
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center font-black text-white text-xl shadow-md border-2 border-white/20"
                      style={{ backgroundColor: `#${char.shirtColor.toString(16).padStart(6, '0')}` }}
                    >
                      {char.name[0]}
                    </div>

                    {isSelected && (
                      <span className="bg-amber-400 text-amber-950 font-black text-xs px-2.5 py-1 rounded-xl flex items-center gap-1 shadow">
                        <Check className="w-3.5 h-3.5 stroke-[3]" /> Active
                      </span>
                    )}
                  </div>

                  <h3 className="text-lg font-black text-white">{char.name}</h3>
                  <div className="text-xs font-bold text-amber-300 mb-1">
                    {char.title}
                  </div>
                  <p className="text-xs text-slate-300 mb-2.5 leading-snug">
                    {char.description}
                  </p>

                  <div className="bg-slate-900/80 rounded-xl px-2.5 py-1 text-[11px] text-emerald-300 font-extrabold border border-emerald-500/30 mb-3">
                    ★ {char.perk}
                  </div>
                </div>

                {/* Action Button */}
                <div>
                  {isUnlocked ? (
                    <button
                      onClick={() => onSelect(char.id)}
                      disabled={isSelected}
                      className={`w-full py-2 px-3 rounded-xl font-black text-xs md:text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                        isSelected
                          ? 'bg-slate-700 text-slate-400 cursor-default'
                          : 'bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 text-white shadow-md active:translate-y-0.5'
                      }`}
                    >
                      {isSelected ? 'Selected' : 'Select Hero'}
                    </button>
                  ) : (
                    <button
                      onClick={() => onUnlock(char)}
                      disabled={!canAfford}
                      className={`w-full py-2 px-3 rounded-xl font-black text-xs md:text-sm transition-all flex items-center justify-center gap-1.5 shadow-md ${
                        canAfford
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-amber-950 cursor-pointer active:translate-y-0.5'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      }`}
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Unlock {char.cost}</span>
                      <Coins className="w-3.5 h-3.5 fill-current" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
