import React, { useState } from 'react';
import { X, Smartphone, Download, Copy, Check, ExternalLink, HelpCircle } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface InstallModalProps {
  onClose: () => void;
}

export const InstallModal: React.FC<InstallModalProps> = ({ onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [copied, setCopied] = useState(false);

  const currentUrl = window.location.href;

  const handleCopyLink = () => {
    try {
      navigator.clipboard.writeText(currentUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (e) {
      // fallback
    }
  };

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        onClose();
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 z-50 flex items-center justify-center p-3 md:p-6 select-none overflow-y-auto">
      <div className="bg-slate-900 border-4 border-emerald-400 rounded-3xl p-5 md:p-7 max-w-lg w-full shadow-2xl relative animate-in fade-in zoom-in-95 duration-150 text-white">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-700/80 pb-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-2xl border border-emerald-500/30">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-emerald-400 uppercase tracking-wide">
                Install on Android Phone
              </h2>
              <p className="text-slate-400 text-xs">
                फोन में गेम इनस्टॉल करें और बिना इंटरनेट भी खेलें!
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* If already installed */}
        {isInstalled ? (
          <div className="bg-emerald-950/60 border border-emerald-500/40 rounded-2xl p-4 text-center mb-4">
            <div className="text-emerald-300 font-black text-lg mb-1">
              ✓ App Already Installed!
            </div>
            <p className="text-slate-300 text-xs">
              Yeh game aapke phone ki home screen par installed hai.
            </p>
          </div>
        ) : isInstallable ? (
          /* Direct Chrome 1-Click Install Button */
          <div className="mb-4">
            <button
              onClick={handleInstallClick}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 active:from-emerald-600 border-b-4 border-green-800 text-white font-black text-lg flex items-center justify-center gap-2.5 shadow-xl active:translate-y-1 transition-all cursor-pointer animate-pulse"
            >
              <Download className="w-6 h-6 stroke-[3]" />
              <span>INSTALL APP NOW (1-Click)</span>
            </button>
            <p className="text-center text-xs text-slate-400 mt-2">
              Tap karein aur turant app aapke phone me install ho jayega!
            </p>
          </div>
        ) : null}

        {/* Step-by-Step Android Instructions (Hindi & English) */}
        <div className="bg-slate-950/70 rounded-2xl p-4 border border-slate-800 mb-4">
          <div className="flex items-center gap-2 text-amber-400 font-black text-sm uppercase mb-3">
            <HelpCircle className="w-4 h-4" />
            <span>Android Phone me Kaise Install Karein (Step-by-Step):</span>
          </div>

          <div className="flex flex-col gap-3 text-xs md:text-sm text-slate-200">
            {/* Step 1 */}
            <div className="flex items-start gap-3 bg-slate-900/90 rounded-xl p-3 border border-slate-800">
              <span className="w-6 h-6 rounded-full bg-emerald-500 text-white font-black flex items-center justify-center shrink-0 text-xs">
                1
              </span>
              <div>
                <strong className="text-white">Phone me Chrome Browser kholein:</strong>
                <p className="text-slate-400 text-xs mt-0.5">
                  Is game ka link apne Android phone ke Google Chrome me open karein.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex items-start gap-3 bg-slate-900/90 rounded-xl p-3 border border-slate-800">
              <span className="w-6 h-6 rounded-full bg-amber-500 text-amber-950 font-black flex items-center justify-center shrink-0 text-xs">
                2
              </span>
              <div>
                <strong className="text-white">Chrome Menu (⋮) par tap karein:</strong>
                <p className="text-slate-400 text-xs mt-0.5">
                  Top-right corner me 3 dots (<strong>⋮</strong>) par click karein.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex items-start gap-3 bg-slate-900/90 rounded-xl p-3 border border-slate-800">
              <span className="w-6 h-6 rounded-full bg-sky-500 text-white font-black flex items-center justify-center shrink-0 text-xs">
                3
              </span>
              <div>
                <strong className="text-white">
                  "Install app" ya "Add to Home screen" chunein:
                </strong>
                <p className="text-slate-400 text-xs mt-0.5">
                  Menu me <strong>"Install app"</strong> (ऐप इंस्टॉल करें) ya <strong>"Add to Home screen"</strong> (होम स्क्रीन में जोड़ें) par tap karein. Game aapke phone ke app drawer me aa jayega!
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Copy Link to open on phone */}
        <div className="bg-slate-800/80 rounded-2xl p-3.5 border border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-300 text-center sm:text-left">
            <div className="font-bold text-white">Game Link for your phone:</div>
            <div className="text-[11px] text-slate-400 truncate max-w-[280px]">
              {currentUrl}
            </div>
          </div>

          <button
            onClick={handleCopyLink}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 active:bg-sky-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shrink-0 shadow"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-200" />
                <span>Link Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copy Game Link</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
