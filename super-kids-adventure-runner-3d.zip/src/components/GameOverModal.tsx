import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { RotateCcw, Home, Trophy, Coins, Footprints, Sparkles } from 'lucide-react';

interface GameOverModalProps {
  score: number;
  coins: number;
  distance: number;
  isHighScore: boolean;
  bestScore: number;
  onRestart: () => void;
  onHome: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  coins,
  distance,
  isHighScore,
  bestScore,
  onRestart,
  onHome,
}) => {
  useEffect(() => {
    if (isHighScore) {
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#ffd700', '#ff4081', '#00e5ff', '#76ff03'],
        });
      } catch (e) {
        // ignore confetti errors
      }
    }
  }, [isHighScore]);

  return (
    <div className="fixed inset-0 bg-slate-950/85 z-50 flex items-center justify-center p-4 select-none overflow-y-auto">
      <div className="bg-slate-900 border-4 border-amber-400 rounded-3xl p-6 md:p-8 max-w-sm sm:max-w-md w-full shadow-2xl text-center relative animate-in fade-in zoom-in-95 duration-200">
        {/* High Score Celebration Badge */}
        {isHighScore ? (
          <div className="inline-flex items-center gap-1.5 bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-amber-950 font-black text-xs md:text-sm uppercase tracking-wider px-4 py-1.5 rounded-full shadow-lg mb-2 animate-bounce">
            <Sparkles className="w-4 h-4 fill-amber-950" />
            <span>NEW HIGH SCORE!</span>
            <Sparkles className="w-4 h-4 fill-amber-950" />
          </div>
        ) : (
          <div className="inline-block text-slate-400 text-xs uppercase font-extrabold tracking-widest mb-1">
            Great Adventure Run!
          </div>
        )}

        <h2 className="text-3xl sm:text-4xl font-black text-amber-400 uppercase tracking-tight mb-4">
          {isHighScore ? 'SUPER RECORD!' : 'GAME OVER'}
        </h2>

        {/* Score Readout Card */}
        <div className="bg-slate-800/90 border-2 border-slate-700 rounded-2xl p-4 mb-4 shadow-inner">
          <div className="text-xs uppercase font-black text-slate-400">
            Final Score
          </div>
          <div className="text-4xl sm:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 via-amber-400 to-orange-400 tabular-nums">
            {score.toLocaleString()}
          </div>

          <div className="flex items-center justify-center gap-2 mt-2 pt-2 border-t border-slate-700/80 text-xs text-slate-300 font-bold">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>Best Record: {bestScore.toLocaleString()}</span>
          </div>
        </div>

        {/* Run Rewards Badges */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="bg-amber-500/15 border border-amber-400/40 rounded-2xl p-3 flex flex-col items-center">
            <Coins className="w-6 h-6 text-amber-400 fill-amber-400 mb-1" />
            <div className="text-[11px] font-black uppercase text-amber-300">
              Coins Collected
            </div>
            <div className="text-xl font-black text-white tabular-nums">
              +{coins}
            </div>
          </div>

          <div className="bg-sky-500/15 border border-sky-400/40 rounded-2xl p-3 flex flex-col items-center">
            <Footprints className="w-6 h-6 text-sky-400 mb-1" />
            <div className="text-[11px] font-black uppercase text-sky-300">
              Distance Ran
            </div>
            <div className="text-xl font-black text-white tabular-nums">
              {distance}m
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-3">
          <button
            onClick={onRestart}
            className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 active:from-emerald-600 active:to-green-700 border-b-4 border-green-800 text-white font-black text-xl flex items-center justify-center gap-2 shadow-xl active:translate-y-1 transition-all cursor-pointer"
          >
            <RotateCcw className="w-6 h-6 stroke-[3]" /> PLAY AGAIN
          </button>

          <button
            onClick={onHome}
            className="w-full py-3 px-6 rounded-2xl bg-slate-800 hover:bg-slate-700 active:bg-slate-900 border-b-4 border-slate-950 text-slate-200 font-bold text-base flex items-center justify-center gap-2 shadow-lg active:translate-y-1 transition-all cursor-pointer"
          >
            <Home className="w-5 h-5" /> Main Menu
          </button>
        </div>
      </div>
    </div>
  );
};
