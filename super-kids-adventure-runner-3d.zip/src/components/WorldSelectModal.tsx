import React from 'react';
import { X, Check, Lock, Coins, Globe, MapPin } from 'lucide-react';
import { WorldConfig } from '../game/types';
import { WORLDS } from '../game/worldConfig';

interface WorldSelectModalProps {
  selectedId: string;
  unlockedIds: string[];
  coins: number;
  onSelect: (id: string) => void;
  onUnlock: (world: WorldConfig) => void;
  onClose: () => void;
}

export const WorldSelectModal: React.FC<WorldSelectModalProps> = ({
  selectedId,
  unlockedIds,
  coins,
  onSelect,
  onUnlock,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/80 z-50 flex items-center justify-center p-3 md:p-6 select-none overflow-y-auto">
      <div className="bg-slate-900 border-4 border-sky-400 rounded-3xl p-5 md:p-7 max-w-2xl w-full shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-700/80 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-sky-500/20 text-sky-400 rounded-2xl">
              <Globe className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl md:text-3xl font-black text-sky-400 uppercase tracking-wide">
                Adventure Worlds
              </h2>
              <p className="text-slate-400 text-xs md:text-sm">
                Explore magical environments with unique scenery & tracks!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-r from-amber-500 to-yellow-400 rounded-xl px-3 py-1 flex items-center gap-1.5 shadow">
              <Coins className="w-4 h-4 text-amber-950 fill-amber-950" />
              <span className="text-amber-950 font-black text-sm tabular-nums">
                {coins}
              </span>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Worlds List */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4 max-h-[65vh] overflow-y-auto pr-1">
          {WORLDS.map((world) => {
            const isUnlocked = unlockedIds.includes(world.id);
            const isSelected = selectedId === world.id;
            const canAfford = coins >= world.cost;

            return (
              <div
                key={world.id}
                className={`flex flex-col justify-between rounded-2xl p-4 border-2 transition-all ${
                  isSelected
                    ? 'bg-sky-500/15 border-sky-400 shadow-[0_0_20px_rgba(56,189,248,0.25)]'
                    : isUnlocked
                    ? 'bg-slate-800/80 border-slate-700 hover:border-slate-500'
                    : 'bg-slate-800/40 border-slate-800 opacity-90'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs uppercase font-black px-2.5 py-0.5 rounded-lg bg-white/10 text-slate-200">
                      {world.theme}
                    </span>

                    {isSelected && (
                      <span className="bg-sky-400 text-sky-950 font-black text-xs px-2.5 py-1 rounded-xl flex items-center gap-1 shadow">
                        <Check className="w-3.5 h-3.5 stroke-[3]" /> Active
                      </span>
                    )}
                  </div>

                  <h3 className="text-xl font-black text-white flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-sky-400" />
                    {world.name}
                  </h3>

                  <p className="text-xs text-slate-300 my-2 leading-relaxed">
                    {world.description}
                  </p>
                </div>

                {/* Action Button */}
                <div className="mt-3">
                  {isUnlocked ? (
                    <button
                      onClick={() => onSelect(world.id)}
                      disabled={isSelected}
                      className={`w-full py-2.5 px-3 rounded-xl font-black text-xs md:text-sm uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 ${
                        isSelected
                          ? 'bg-slate-700 text-slate-400 cursor-default'
                          : 'bg-sky-500 hover:bg-sky-400 active:bg-sky-600 text-white shadow-md active:translate-y-0.5'
                      }`}
                    >
                      {isSelected ? 'Selected' : 'Travel Here'}
                    </button>
                  ) : (
                    <button
                      onClick={() => onUnlock(world)}
                      disabled={!canAfford}
                      className={`w-full py-2.5 px-3 rounded-xl font-black text-xs md:text-sm transition-all flex items-center justify-center gap-1.5 shadow-md ${
                        canAfford
                          ? 'bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-amber-950 cursor-pointer active:translate-y-0.5'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      }`}
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Unlock {world.cost}</span>
                      <Coins className="w-3.5 h-3.5 fill-current" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
