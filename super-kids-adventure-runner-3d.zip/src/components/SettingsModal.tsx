import React from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Music,
  Gamepad2,
  Smartphone,
  Sparkles,
  Shield,
  Zap,
  Magnet,
  Rocket,
} from 'lucide-react';

interface SettingsModalProps {
  soundEnabled: boolean;
  musicEnabled: boolean;
  showMobileControls: boolean;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onToggleMobileControls: () => void;
  onOpenInstall: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  soundEnabled,
  musicEnabled,
  showMobileControls,
  onToggleSound,
  onToggleMusic,
  onToggleMobileControls,
  onOpenInstall,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/80 z-50 flex items-center justify-center p-3 md:p-6 select-none overflow-y-auto">
      <div className="bg-slate-900 border-4 border-slate-700 rounded-3xl p-5 md:p-7 max-w-lg w-full shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-700/80 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-slate-800 text-amber-400 rounded-2xl">
              <Gamepad2 className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-white uppercase tracking-wide">
                Settings & Guide
              </h2>
              <p className="text-slate-400 text-xs">
                Customize audio and review runner controls!
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Toggles */}
        <div className="flex flex-col gap-2.5 mb-5">
          {/* Sound FX Toggle */}
          <div className="flex items-center justify-between bg-slate-800/80 rounded-2xl p-3 border border-slate-700">
            <div className="flex items-center gap-2.5">
              {soundEnabled ? (
                <Volume2 className="w-5 h-5 text-emerald-400" />
              ) : (
                <VolumeX className="w-5 h-5 text-slate-500" />
              )}
              <span className="font-bold text-sm text-white">Sound Effects</span>
            </div>
            <button
              onClick={onToggleSound}
              className={`px-4 py-1.5 rounded-xl font-black text-xs transition-colors ${
                soundEnabled
                  ? 'bg-emerald-500 text-white'
                  : 'bg-slate-700 text-slate-400'
              }`}
            >
              {soundEnabled ? 'ON' : 'OFF'}
            </button>
          </div>

          {/* Music Toggle */}
          <div className="flex items-center justify-between bg-slate-800/80 rounded-2xl p-3 border border-slate-700">
            <div className="flex items-center gap-2.5">
              <Music
                className={`w-5 h-5 ${
                  musicEnabled ? 'text-amber-400' : 'text-slate-500'
                }`}
              />
              <span className="font-bold text-sm text-white">Cheerful Music</span>
            </div>
            <button
              onClick={onToggleMusic}
              className={`px-4 py-1.5 rounded-xl font-black text-xs transition-colors ${
                musicEnabled
                  ? 'bg-amber-500 text-amber-950'
                  : 'bg-slate-700 text-slate-400'
              }`}
            >
              {musicEnabled ? 'ON' : 'OFF'}
            </button>
          </div>

          {/* Mobile Buttons Toggle */}
          <div className="flex items-center justify-between bg-slate-800/80 rounded-2xl p-3 border border-slate-700">
            <div className="flex items-center gap-2.5">
              <Smartphone
                className={`w-5 h-5 ${
                  showMobileControls ? 'text-sky-400' : 'text-slate-500'
                }`}
              />
              <span className="font-bold text-sm text-white">
                On-Screen Tap Buttons
              </span>
            </div>
            <button
              onClick={onToggleMobileControls}
              className={`px-4 py-1.5 rounded-xl font-black text-xs transition-colors ${
                showMobileControls
                  ? 'bg-sky-500 text-white'
                  : 'bg-slate-700 text-slate-400'
              }`}
            >
              {showMobileControls ? 'VISIBLE' : 'HIDDEN'}
            </button>
          </div>

          {/* Install on Android Phone Button */}
          <button
            onClick={() => {
              onClose();
              onOpenInstall();
            }}
            className="w-full mt-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg active:translate-y-0.5 transition-all border border-emerald-400"
          >
            <Smartphone className="w-5 h-5" />
            <span>Install Game on Phone (फोन में इनस्टॉल करें)</span>
          </button>
        </div>

        {/* How to Play Guide for Kids */}
        <div className="bg-slate-950/60 rounded-2xl p-4 border border-slate-800">
          <div className="text-xs uppercase font-black text-amber-400 mb-2 tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-4 h-4" /> How to Play
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs text-slate-300 mb-3">
            <div className="bg-slate-900/80 rounded-xl p-2 border border-slate-800">
              <span className="text-amber-300 font-extrabold">← → / Swipe:</span> Switch lanes
            </div>
            <div className="bg-slate-900/80 rounded-xl p-2 border border-slate-800">
              <span className="text-emerald-300 font-extrabold">↑ / Swipe Up:</span> Jump over hurdles
            </div>
            <div className="bg-slate-900/80 rounded-xl p-2 border border-slate-800">
              <span className="text-purple-300 font-extrabold">↓ / Swipe Down:</span> Slide under arches
            </div>
            <div className="bg-slate-900/80 rounded-xl p-2 border border-slate-800">
              <span className="text-sky-300 font-extrabold">Down in Air:</span> Fast ground dive
            </div>
          </div>

          {/* Power-up cheat sheet */}
          <div className="text-[11px] text-slate-400 font-semibold grid grid-cols-2 gap-1.5">
            <div className="flex items-center gap-1">
              <Magnet className="w-3.5 h-3.5 text-amber-400" /> Magnet: Sucks coins
            </div>
            <div className="flex items-center gap-1">
              <Shield className="w-3.5 h-3.5 text-cyan-400" /> Shield: Blocks 1 hit
            </div>
            <div className="flex items-center gap-1">
              <Rocket className="w-3.5 h-3.5 text-red-400" /> Rocket: Warp invincibility
            </div>
            <div className="flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-emerald-400" /> Spring: Mega jump
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
