import React from 'react';
import {
  Coins,
  Pause,
  Play,
  RotateCcw,
  Home,
  Shield,
  Zap,
  Magnet,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Sparkles,
  Rocket,
} from 'lucide-react';
import { PowerUpActive } from '../game/types';

interface GameHUDProps {
  score: number;
  coins: number;
  distance: number;
  powerUps: PowerUpActive[];
  isPaused: boolean;
  showMobileControls: boolean;
  onPause: () => void;
  onResume: () => void;
  onRestart: () => void;
  onHome: () => void;
  onMoveLeft: () => void;
  onMoveRight: () => void;
  onJump: () => void;
  onSlide: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  score,
  coins,
  distance,
  powerUps,
  isPaused,
  showMobileControls,
  onPause,
  onResume,
  onRestart,
  onHome,
  onMoveLeft,
  onMoveRight,
  onJump,
  onSlide,
}) => {
  const getPowerUpIcon = (type: string) => {
    switch (type) {
      case 'MAGNET':
        return <Magnet className="w-5 h-5 text-amber-300" />;
      case 'SHIELD':
        return <Shield className="w-5 h-5 text-cyan-300" />;
      case 'SUPER_JUMP':
        return <Zap className="w-5 h-5 text-emerald-300" />;
      case 'ROCKET':
        return <Rocket className="w-5 h-5 text-red-400" />;
      case 'DOUBLE_COINS':
        return <Sparkles className="w-5 h-5 text-purple-300" />;
      default:
        return <Zap className="w-5 h-5 text-yellow-300" />;
    }
  };

  const getPowerUpLabel = (type: string) => {
    switch (type) {
      case 'MAGNET':
        return 'Magnet';
      case 'SHIELD':
        return 'Shield';
      case 'SUPER_JUMP':
        return 'Super Jump';
      case 'ROCKET':
        return 'Rocket Boost';
      case 'DOUBLE_COINS':
        return '2X Coins';
      default:
        return 'Boost';
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none z-20 flex flex-col justify-between p-3 md:p-6 overflow-hidden">
      {/* Top Header Status Clusters */}
      <div className="flex items-center justify-between w-full">
        {/* Left: Score & Distance */}
        <div className="flex items-center gap-2 md:gap-3">
          <div className="bg-slate-900/85 border-2 border-amber-400/80 rounded-2xl px-3.5 py-1.5 shadow-lg flex items-center gap-2">
            <span className="text-amber-300 text-xs md:text-sm font-black tracking-wider uppercase">
              Score
            </span>
            <span className="text-white font-extrabold text-base md:text-xl tabular-nums">
              {score.toLocaleString()}
            </span>
          </div>

          <div className="bg-slate-900/85 border-2 border-sky-400/80 rounded-2xl px-3 py-1.5 shadow-lg flex items-center gap-1.5">
            <span className="text-sky-300 text-xs md:text-sm font-black uppercase">
              Dist
            </span>
            <span className="text-white font-extrabold text-sm md:text-lg tabular-nums">
              {distance}m
            </span>
          </div>
        </div>

        {/* Right: Coins Collected & Pause Button */}
        <div className="flex items-center gap-2 md:gap-3">
          <div className="bg-gradient-to-r from-amber-500 to-yellow-400 border-2 border-yellow-200 rounded-2xl px-3.5 py-1.5 shadow-lg flex items-center gap-1.5">
            <Coins className="w-5 h-5 text-amber-950 fill-amber-950 animate-bounce" />
            <span className="text-amber-950 font-black text-base md:text-xl tabular-nums">
              {coins}
            </span>
          </div>

          <button
            onClick={onPause}
            className="pointer-events-auto bg-slate-900/90 hover:bg-slate-800 active:scale-95 text-white border-2 border-slate-600 rounded-2xl p-2.5 shadow-lg transition-transform"
            title="Pause Game"
          >
            <Pause className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Active Power-Ups Stack (Left Side) */}
      <div className="flex flex-col gap-2 max-w-[220px] mt-2">
        {powerUps.map((p) => {
          const pct = Math.max(0, Math.min(100, (p.remaining / p.duration) * 100));
          return (
            <div
              key={p.type}
              className="bg-slate-950/85 border border-white/20 rounded-xl p-2 shadow-md flex items-center gap-2.5 backdrop-blur-none"
            >
              <div className="p-1.5 rounded-lg bg-white/10">{getPowerUpIcon(p.type)}</div>
              <div className="flex-1">
                <div className="flex justify-between text-xs font-bold text-white mb-1">
                  <span>{getPowerUpLabel(p.type)}</span>
                  <span className="text-amber-300 tabular-nums">
                    {Math.ceil(p.remaining)}s
                  </span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-amber-400 to-yellow-300 h-full rounded-full transition-all duration-100"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Controls Area */}
      <div className="w-full flex flex-col items-center gap-2">
        {/* On-Screen Mobile Action Controls */}
        {showMobileControls && (
          <div className="pointer-events-auto w-full max-w-md flex justify-between items-end px-3 pb-2 gap-3">
            {/* Left/Right Directional Buttons */}
            <div className="flex gap-2">
              <button
                onPointerDown={onMoveLeft}
                className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-amber-500 active:bg-amber-600 border-b-4 border-amber-700 text-amber-950 font-black shadow-xl flex items-center justify-center active:translate-y-1 transition-all"
                aria-label="Move Left"
              >
                <ArrowLeft className="w-7 h-7 stroke-[3]" />
              </button>
              <button
                onPointerDown={onMoveRight}
                className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-amber-500 active:bg-amber-600 border-b-4 border-amber-700 text-amber-950 font-black shadow-xl flex items-center justify-center active:translate-y-1 transition-all"
                aria-label="Move Right"
              >
                <ArrowRight className="w-7 h-7 stroke-[3]" />
              </button>
            </div>

            {/* Jump and Slide Buttons */}
            <div className="flex gap-2">
              <button
                onPointerDown={onSlide}
                className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-purple-500 active:bg-purple-600 border-b-4 border-purple-700 text-white font-black shadow-xl flex flex-col items-center justify-center active:translate-y-1 transition-all"
                aria-label="Slide"
              >
                <ArrowDown className="w-6 h-6 stroke-[3]" />
                <span className="text-[10px] font-black uppercase">Slide</span>
              </button>
              <button
                onPointerDown={onJump}
                className="w-16 h-16 md:w-18 md:h-18 rounded-2xl bg-emerald-500 active:bg-emerald-600 border-b-4 border-emerald-700 text-white font-black shadow-xl flex flex-col items-center justify-center active:translate-y-1 transition-all"
                aria-label="Jump"
              >
                <ArrowUp className="w-7 h-7 stroke-[3]" />
                <span className="text-[11px] font-black uppercase">Jump</span>
              </button>
            </div>
          </div>
        )}

        {/* Minimal Control Hint (Desktop) */}
        {!showMobileControls && (
          <div className="bg-slate-950/60 text-slate-300 text-xs px-4 py-1.5 rounded-full border border-white/10 font-medium">
            Swipe or use <span className="text-amber-400 font-bold">← →</span> to move,{' '}
            <span className="text-emerald-400 font-bold">↑</span> to jump,{' '}
            <span className="text-purple-400 font-bold">↓</span> to slide
          </div>
        )}
      </div>

      {/* Pause Modal Overlay */}
      {isPaused && (
        <div className="pointer-events-auto fixed inset-0 bg-slate-950/80 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border-4 border-amber-400 rounded-3xl p-6 md:p-8 max-w-sm w-full text-center shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <h2 className="text-3xl font-black text-amber-400 uppercase tracking-wide mb-2">
              Game Paused
            </h2>
            <p className="text-slate-300 text-sm mb-6">
              Catch your breath! Your kid runner is waiting.
            </p>

            <div className="flex flex-col gap-3">
              <button
                onClick={onResume}
                className="w-full py-3.5 px-6 rounded-2xl bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 border-b-4 border-emerald-700 text-white font-black text-lg flex items-center justify-center gap-2 shadow-lg active:translate-y-1 transition-all"
              >
                <Play className="w-6 h-6 fill-white" /> Resume
              </button>

              <button
                onClick={onRestart}
                className="w-full py-3 px-6 rounded-2xl bg-sky-500 hover:bg-sky-400 active:bg-sky-600 border-b-4 border-sky-700 text-white font-black text-base flex items-center justify-center gap-2 shadow-lg active:translate-y-1 transition-all"
              >
                <RotateCcw className="w-5 h-5" /> Restart
              </button>

              <button
                onClick={onHome}
                className="w-full py-3 px-6 rounded-2xl bg-slate-700 hover:bg-slate-600 active:bg-slate-800 border-b-4 border-slate-900 text-slate-200 font-bold text-base flex items-center justify-center gap-2 shadow-lg active:translate-y-1 transition-all"
              >
                <Home className="w-5 h-5" /> Main Menu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
