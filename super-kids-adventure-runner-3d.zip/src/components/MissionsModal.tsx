import React from 'react';
import { X, Award, CheckCircle2, Coins } from 'lucide-react';
import { Mission } from '../game/types';

interface MissionsModalProps {
  missions: Mission[];
  onClose: () => void;
}

export const MissionsModal: React.FC<MissionsModalProps> = ({
  missions,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/80 z-50 flex items-center justify-center p-3 md:p-6 select-none overflow-y-auto">
      <div className="bg-slate-900 border-4 border-purple-400 rounded-3xl p-5 md:p-7 max-w-lg w-full shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-700/80 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-purple-500/20 text-purple-400 rounded-2xl">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl md:text-3xl font-black text-purple-400 uppercase tracking-wide">
                Runner Quests
              </h2>
              <p className="text-slate-400 text-xs md:text-sm">
                Complete exciting milestones to earn shiny coin rewards!
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Missions List */}
        <div className="flex flex-col gap-3 max-h-[60vh] overflow-y-auto pr-1">
          {missions.map((m) => {
            const pct = Math.min(100, Math.floor((m.current / m.target) * 100));

            return (
              <div
                key={m.id}
                className={`p-3.5 rounded-2xl border-2 flex items-center gap-3 ${
                  m.completed
                    ? 'bg-emerald-950/40 border-emerald-500/50'
                    : 'bg-slate-800/80 border-slate-700'
                }`}
              >
                <div
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 ${
                    m.completed
                      ? 'bg-emerald-500 text-white'
                      : 'bg-purple-500/20 text-purple-300 border border-purple-400/40'
                  }`}
                >
                  {m.completed ? (
                    <CheckCircle2 className="w-6 h-6" />
                  ) : (
                    <Award className="w-6 h-6" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-0.5">
                    <h3 className="text-sm font-black text-white truncate">
                      {m.title}
                    </h3>
                    <div className="flex items-center gap-1 bg-amber-400/20 px-2 py-0.5 rounded-lg text-amber-300 font-extrabold text-xs">
                      +{m.reward} <Coins className="w-3.5 h-3.5 fill-amber-300" />
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 mb-2">{m.description}</p>

                  {/* Progress Bar */}
                  <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden flex items-center">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        m.completed ? 'bg-emerald-400' : 'bg-purple-400'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-slate-400 font-bold mt-1 text-right tabular-nums">
                    {m.current} / {m.target} ({pct}%)
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
