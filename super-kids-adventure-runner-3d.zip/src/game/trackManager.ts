import * as THREE from 'three';
import { CollectibleInstance, Lane, ObstacleInstance, ObstacleType, PowerUpType, WorldConfig } from './types';
import { LANE_WIDTH } from './player';
import {
  createCoinMesh,
  createEnvironmentProp,
  createGemMesh,
  createObstacleMesh,
  createPowerUpMesh,
} from './proceduralModels';

const CHUNK_LENGTH = 30; // Length of each road tile
const VISIBLE_CHUNKS = 6; // Chunks maintained ahead of player

export class TrackManager {
  private scene: THREE.Scene;
  private currentWorld: WorldConfig;
  private trackGroup: THREE.Group;
  private obstaclesGroup: THREE.Group;
  private collectiblesGroup: THREE.Group;
  private sceneryGroup: THREE.Group;

  public activeObstacles: ObstacleInstance[] = [];
  public activeCollectibles: CollectibleInstance[] = [];
  private chunks: { mesh: THREE.Group; zStart: number; zEnd: number }[] = [];

  private nextSpawnZ = -15; // Z position of next chunk spawn (negative Z is forward)
  private obstacleIdCounter = 1;
  private collectibleIdCounter = 1;

  constructor(scene: THREE.Scene, world: WorldConfig) {
    this.scene = scene;
    this.currentWorld = world;

    this.trackGroup = new THREE.Group();
    this.obstaclesGroup = new THREE.Group();
    this.collectiblesGroup = new THREE.Group();
    this.sceneryGroup = new THREE.Group();

    this.scene.add(this.trackGroup);
    this.scene.add(this.obstaclesGroup);
    this.scene.add(this.collectiblesGroup);
    this.scene.add(this.sceneryGroup);

    this.initTrack();
  }

  public setWorld(world: WorldConfig) {
    this.currentWorld = world;
    this.reset();
  }

  public reset() {
    // Clear all existing meshes
    this.clearGroup(this.trackGroup);
    this.clearGroup(this.obstaclesGroup);
    this.clearGroup(this.collectiblesGroup);
    this.clearGroup(this.sceneryGroup);

    this.activeObstacles = [];
    this.activeCollectibles = [];
    this.chunks = [];
    this.nextSpawnZ = 10; // Start slightly behind player (z=0)

    this.initTrack();
  }

  private clearGroup(group: THREE.Group) {
    while (group.children.length > 0) {
      const obj = group.children[0];
      group.remove(obj);
      if ((obj as THREE.Mesh).geometry) {
        (obj as THREE.Mesh).geometry.dispose();
      }
    }
  }

  private initTrack() {
    // Spawn initial chunks
    for (let i = 0; i < VISIBLE_CHUNKS; i++) {
      const isIntro = i < 2; // Keep first 2 chunks completely free of obstacles so kid can get ready!
      this.spawnChunk(this.nextSpawnZ, isIntro);
      this.nextSpawnZ -= CHUNK_LENGTH;
    }
  }

  private spawnChunk(zPos: number, isIntro: boolean) {
    const chunkGroup = new THREE.Group();
    chunkGroup.position.z = zPos;

    // 1. Playable Road Track (3 lanes wide ~ 8.4m)
    const roadWidth = LANE_WIDTH * 3 + 1.2;
    const roadGeo = new THREE.PlaneGeometry(roadWidth, CHUNK_LENGTH);
    roadGeo.rotateX(-Math.PI / 2);
    const roadMat = new THREE.MeshStandardMaterial({
      color: this.currentWorld.trackColor,
      roughness: 0.8,
      metalness: 0.1,
    });
    const road = new THREE.Mesh(roadGeo, roadMat);
    road.position.set(0, 0, -CHUNK_LENGTH / 2);
    road.receiveShadow = true;
    chunkGroup.add(road);

    // 2. Lane Divider Stripes
    const stripeGeo = new THREE.PlaneGeometry(0.12, CHUNK_LENGTH * 0.7);
    stripeGeo.rotateX(-Math.PI / 2);
    const stripeMat = new THREE.MeshBasicMaterial({ color: this.currentWorld.stripeColor });

    const stripeLeft = new THREE.Mesh(stripeGeo, stripeMat);
    stripeLeft.position.set(-LANE_WIDTH / 2, 0.01, -CHUNK_LENGTH / 2);
    chunkGroup.add(stripeLeft);

    const stripeRight = new THREE.Mesh(stripeGeo, stripeMat);
    stripeRight.position.set(LANE_WIDTH / 2, 0.01, -CHUNK_LENGTH / 2);
    chunkGroup.add(stripeRight);

    // 3. Side Curbs / Borders
    const curbGeo = new THREE.BoxGeometry(0.4, 0.25, CHUNK_LENGTH);
    const curbMat = new THREE.MeshStandardMaterial({
      color: this.currentWorld.groundColor,
      roughness: 0.9,
    });

    const curbLeft = new THREE.Mesh(curbGeo, curbMat);
    curbLeft.position.set(-roadWidth / 2 - 0.2, 0.125, -CHUNK_LENGTH / 2);
    curbLeft.castShadow = true;
    curbLeft.receiveShadow = true;
    chunkGroup.add(curbLeft);

    const curbRight = new THREE.Mesh(curbGeo, curbMat);
    curbRight.position.set(roadWidth / 2 + 0.2, 0.125, -CHUNK_LENGTH / 2);
    curbRight.castShadow = true;
    curbRight.receiveShadow = true;
    chunkGroup.add(curbRight);

    // 4. Side Grass/Terrain extensions
    const terrainGeo = new THREE.PlaneGeometry(40, CHUNK_LENGTH);
    terrainGeo.rotateX(-Math.PI / 2);
    const terrainMat = new THREE.MeshStandardMaterial({
      color: this.currentWorld.groundColor,
      roughness: 0.95,
      metalness: 0.05,
    });

    const leftTerrain = new THREE.Mesh(terrainGeo, terrainMat);
    leftTerrain.position.set(-roadWidth / 2 - 20.4, -0.05, -CHUNK_LENGTH / 2);
    leftTerrain.receiveShadow = true;
    chunkGroup.add(leftTerrain);

    const rightTerrain = new THREE.Mesh(terrainGeo, terrainMat);
    rightTerrain.position.set(roadWidth / 2 + 20.4, -0.05, -CHUNK_LENGTH / 2);
    rightTerrain.receiveShadow = true;
    chunkGroup.add(rightTerrain);

    // 5. Scenery props along sides (trees, lollipops, skyscrapers, etc.)
    const propCount = 3;
    for (let p = 0; p < propCount; p++) {
      const pz = zPos - (p + 0.5) * (CHUNK_LENGTH / propCount);

      // Left prop
      const leftProp = createEnvironmentProp(this.currentWorld.theme, 'left');
      leftProp.position.set(-roadWidth / 2 - 1.8 - Math.random() * 2.0, 0, pz);
      this.sceneryGroup.add(leftProp);

      // Right prop
      const rightProp = createEnvironmentProp(this.currentWorld.theme, 'right');
      rightProp.position.set(roadWidth / 2 + 1.8 + Math.random() * 2.0, 0, pz);
      this.sceneryGroup.add(rightProp);
    }

    this.trackGroup.add(chunkGroup);
    this.chunks.push({
      mesh: chunkGroup,
      zStart: zPos,
      zEnd: zPos - CHUNK_LENGTH,
    });

    // 6. Spawn gameplay elements (obstacles, coins, powerups) if not in the introductory start zone
    if (!isIntro) {
      this.populateChunkGameplay(zPos);
    }
  }

  private populateChunkGameplay(chunkStartZ: number) {
    const lanes: Lane[] = [-1, 0, 1];

    // Pick 1 to 2 obstacle encounters per chunk
    const encounterCount = Math.random() > 0.4 ? 2 : 1;

    for (let e = 0; e < encounterCount; e++) {
      const encounterZ = chunkStartZ - 8 - e * 13;
      const pattern = Math.random();

      if (pattern < 0.35) {
        // Pattern A: Low hurdle in 1 or 2 lanes (Jump over) + golden arc of coins over it!
        const targetLane = lanes[Math.floor(Math.random() * lanes.length)];
        const obsType: ObstacleType = Math.random() > 0.5 ? 'BOX_HURDLE' : 'BARREL_ROLL';
        this.spawnObstacle(obsType, targetLane, encounterZ);

        // Spawn jump arc of coins directly over the hurdle!
        this.spawnJumpCoinArc(targetLane, encounterZ);

        // Also add coins in an open lane
        const openLanes = lanes.filter((l) => l !== targetLane);
        const coinLane = openLanes[Math.floor(Math.random() * openLanes.length)];
        this.spawnCoinLine(coinLane, encounterZ - 4, 3);
      } else if (pattern < 0.65) {
        // Pattern B: Overhead arch / barrier (Slide under) + coins flat on the floor underneath!
        const targetLane = lanes[Math.floor(Math.random() * lanes.length)];
        this.spawnObstacle('HANGING_BARRIER', targetLane, encounterZ);

        // Ground coins under the barrier to reward sliding
        for (let i = -2; i <= 2; i++) {
          this.spawnCoin(targetLane, encounterZ + i * 1.5, 0.4);
        }
      } else if (pattern < 0.85) {
        // Pattern C: Tall obstacle blocking 1 lane + moving cartoon car in another
        const blockedLane = lanes[Math.floor(Math.random() * lanes.length)];
        this.spawnObstacle('TALL_TOTEM', blockedLane, encounterZ);

        const openLanes = lanes.filter((l) => l !== blockedLane);
        const secondLane = openLanes[0];
        if (Math.random() > 0.4) {
          this.spawnObstacle('CARTOON_CAR', secondLane, encounterZ - 2, true);
        }

        // Coins leading through the clear safe lane
        const safeLane = openLanes[openLanes.length - 1];
        this.spawnCoinLine(safeLane, encounterZ - 5, 4);
      } else {
        // Pattern D: Traffic cones with coin wave
        const coneLane = lanes[Math.floor(Math.random() * lanes.length)];
        this.spawnObstacle('TRAFFIC_CONES', coneLane, encounterZ);
        this.spawnCoinLine(0, encounterZ - 4, 3);
      }

      // Bonus Collectible: Rare Gem or Power-up Box
      if (Math.random() < 0.28) {
        const bonusZ = encounterZ - 6;
        const availableLanes = [-1, 0, 1] as Lane[];
        const bonusLane = availableLanes[Math.floor(Math.random() * availableLanes.length)];

        if (Math.random() < 0.35) {
          // Rare Rainbow Gem
          this.spawnGem(bonusLane, bonusZ);
        } else {
          // Power-Up Mystery Cube
          const powerTypes: PowerUpType[] = ['MAGNET', 'SUPER_JUMP', 'SHIELD', 'ROCKET', 'DOUBLE_COINS'];
          const powerType = powerTypes[Math.floor(Math.random() * powerTypes.length)];
          this.spawnPowerUp(powerType, bonusLane, bonusZ);
        }
      }
    }
  }

  private spawnObstacle(type: ObstacleType, lane: Lane, z: number, isMoving = false) {
    const mesh = createObstacleMesh(type, this.currentWorld.theme);
    const x = lane * LANE_WIDTH;
    mesh.position.set(x, 0, z);
    this.obstaclesGroup.add(mesh);

    let width = 1.4;
    let height = 0.9;
    let depth = 0.8;
    let requiresSlide = false;
    let requiresJump = false;

    if (type === 'HANGING_BARRIER' || type === 'ARCH_LOG') {
      height = 2.4;
      requiresSlide = true;
    } else if (type === 'BOX_HURDLE' || type === 'BARREL_ROLL' || type === 'TRAFFIC_CONES') {
      requiresJump = true;
      height = 0.8;
    } else if (type === 'TALL_TOTEM' || type === 'DOUBLE_CRATES') {
      height = 3.2;
    } else if (type === 'CARTOON_CAR') {
      height = 1.1;
      depth = 1.8;
    }

    this.activeObstacles.push({
      id: this.obstacleIdCounter++,
      type,
      lane,
      z,
      y: 0,
      width,
      height,
      depth,
      isMoving,
      speedZ: isMoving ? 3.5 : 0, // slowly moves along track
      requiresSlide,
      requiresJump,
      mesh,
    });
  }

  private spawnCoin(lane: Lane, z: number, y = 0.6) {
    const mesh = createCoinMesh();
    const x = lane * LANE_WIDTH;
    mesh.position.set(x, y, z);
    this.collectiblesGroup.add(mesh);

    this.activeCollectibles.push({
      id: this.collectibleIdCounter++,
      type: 'COIN',
      lane,
      x,
      y,
      z,
      collected: false,
      mesh,
    });
  }

  private spawnCoinLine(lane: Lane, startZ: number, count: number) {
    for (let i = 0; i < count; i++) {
      this.spawnCoin(lane, startZ - i * 2.2, 0.6);
    }
  }

  private spawnJumpCoinArc(lane: Lane, centerZ: number) {
    // Beautiful parabolic arc of 5 coins peaking over the hurdle
    const offsets = [-4, -2, 0, 2, 4];
    const heights = [0.6, 1.6, 2.5, 1.6, 0.6];
    offsets.forEach((oz, i) => {
      this.spawnCoin(lane, centerZ + oz, heights[i]);
    });
  }

  private spawnGem(lane: Lane, z: number) {
    const mesh = createGemMesh();
    const x = lane * LANE_WIDTH;
    const y = 1.2;
    mesh.position.set(x, y, z);
    this.collectiblesGroup.add(mesh);

    this.activeCollectibles.push({
      id: this.collectibleIdCounter++,
      type: 'GEM',
      lane,
      x,
      y,
      z,
      collected: false,
      mesh,
    });
  }

  private spawnPowerUp(powerType: PowerUpType, lane: Lane, z: number) {
    const mesh = createPowerUpMesh(powerType);
    const x = lane * LANE_WIDTH;
    const y = 1.2;
    mesh.position.set(x, y, z);
    this.collectiblesGroup.add(mesh);

    this.activeCollectibles.push({
      id: this.collectibleIdCounter++,
      type: powerType,
      lane,
      x,
      y,
      z,
      collected: false,
      mesh,
    });
  }

  public update(playerZ: number, delta: number, hasMagnet = false, playerPos?: THREE.Vector3) {
    // 1. Check if we need to spawn new chunks ahead
    const furthestZ = this.chunks.length > 0 ? this.chunks[this.chunks.length - 1].zEnd : 0;
    if (playerZ - furthestZ < (VISIBLE_CHUNKS - 1) * CHUNK_LENGTH) {
      this.spawnChunk(this.nextSpawnZ, false);
      this.nextSpawnZ -= CHUNK_LENGTH;
    }

    // 2. Recycle old chunks that passed behind player
    if (this.chunks.length > 0 && this.chunks[0].zEnd > playerZ + 25) {
      const oldChunk = this.chunks.shift()!;
      this.trackGroup.remove(oldChunk.mesh);
    }

    // 3. Recycle old scenery
    for (let i = this.sceneryGroup.children.length - 1; i >= 0; i--) {
      const child = this.sceneryGroup.children[i];
      if (child.position.z > playerZ + 25) {
        this.sceneryGroup.remove(child);
      }
    }

    // 4. Update moving obstacles & clean up passed obstacles
    for (let i = this.activeObstacles.length - 1; i >= 0; i--) {
      const obs = this.activeObstacles[i];

      if (obs.isMoving && obs.mesh) {
        // Slowly move along track
        obs.z += (obs.speedZ || 0) * delta;
        obs.mesh.position.z = obs.z;
      }

      if (obs.type === 'BARREL_ROLL' && obs.mesh) {
        // Rotate rolling barrel
        obs.mesh.rotation.x += delta * 6;
      }

      // Recycle if behind player
      if (obs.z > playerZ + 20) {
        if (obs.mesh) {
          this.obstaclesGroup.remove(obs.mesh);
        }
        this.activeObstacles.splice(i, 1);
      }
    }

    // 5. Update collectibles (spin coins/gems, magnet pull, clean up)
    for (let i = this.activeCollectibles.length - 1; i >= 0; i--) {
      const item = this.activeCollectibles[i];

      if (item.collected) {
        // Pop float up animation then remove
        if (item.mesh) {
          item.mesh.position.y += delta * 7;
          item.mesh.scale.multiplyScalar(Math.max(0, 1 - delta * 5));
          if (item.mesh.scale.x < 0.1) {
            this.collectiblesGroup.remove(item.mesh);
            this.activeCollectibles.splice(i, 1);
          }
        } else {
          this.activeCollectibles.splice(i, 1);
        }
        continue;
      }

      if (item.mesh) {
        // Continuous joyful spin
        item.mesh.rotation.y += delta * 4;

        // Magnet attraction effect: if magnet active and coin is within range (~14m)
        if (hasMagnet && playerPos && item.type === 'COIN') {
          const distZ = Math.abs(item.z - playerPos.z);
          if (distZ < 15 && item.z < playerPos.z + 1) {
            // Draw towards player with smooth acceleration
            const target = playerPos.clone();
            target.y += 0.8;
            item.mesh.position.lerp(target, 1 - Math.exp(-12 * delta));
            item.x = item.mesh.position.x;
            item.y = item.mesh.position.y;
            item.z = item.mesh.position.z;
          }
        }
      }

      // Recycle if behind player
      if (item.z > playerZ + 15) {
        if (item.mesh) {
          this.collectiblesGroup.remove(item.mesh);
        }
        this.activeCollectibles.splice(i, 1);
      }
    }
  }
}
