import { Mission, PlayerStats } from './types';

const STORAGE_KEY = 'super_kids_runner_data_v1';
const MISSIONS_KEY = 'super_kids_runner_missions_v1';
const DAILY_KEY = 'super_kids_runner_daily_v1';

export const INITIAL_STATS: PlayerStats = {
  coins: 50, // Starting gift coins for fun
  gems: 2,
  highScore: 0,
  bestDistance: 0,
  runsPlayed: 0,
  selectedCharacter: 'leo',
  selectedWorld: 'jungle',
  unlockedCharacters: ['leo'],
  unlockedWorlds: ['jungle'],
  soundEnabled: true,
  musicEnabled: true,
  showMobileControls: false,
};

export const INITIAL_MISSIONS: Mission[] = [
  {
    id: 'm1',
    title: 'Coin Collector',
    description: 'Collect 100 shiny gold coins',
    target: 100,
    current: 0,
    reward: 150,
    completed: false,
    type: 'COINS',
  },
  {
    id: 'm2',
    title: 'Distance Runner',
    description: 'Run 500 meters in a single run',
    target: 500,
    current: 0,
    reward: 200,
    completed: false,
    type: 'DISTANCE',
  },
  {
    id: 'm3',
    title: 'Super Jumper',
    description: 'Jump over 10 hurdles or boxes',
    target: 10,
    current: 0,
    reward: 120,
    completed: false,
    type: 'JUMPS',
  },
  {
    id: 'm4',
    title: 'Smooth Slider',
    description: 'Slide under 6 overhead barriers',
    target: 6,
    current: 0,
    reward: 120,
    completed: false,
    type: 'SLIDES',
  },
  {
    id: 'm5',
    title: 'Power Surge',
    description: 'Collect 4 power-up boosts',
    target: 4,
    current: 0,
    reward: 180,
    completed: false,
    type: 'POWERUPS',
  },
];

export function loadPlayerStats(): PlayerStats {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...INITIAL_STATS };
    const parsed = JSON.parse(raw);
    return {
      ...INITIAL_STATS,
      ...parsed,
      unlockedCharacters: parsed.unlockedCharacters || ['leo'],
      unlockedWorlds: parsed.unlockedWorlds || ['jungle'],
    };
  } catch (e) {
    console.warn('Failed to load player stats from localStorage', e);
    return { ...INITIAL_STATS };
  }
}

export function savePlayerStats(stats: PlayerStats): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
  } catch (e) {
    console.warn('Failed to save player stats to localStorage', e);
  }
}

export function loadMissions(): Mission[] {
  try {
    const raw = localStorage.getItem(MISSIONS_KEY);
    if (!raw) return [...INITIAL_MISSIONS];
    const parsed = JSON.parse(raw);
    return parsed.length ? parsed : [...INITIAL_MISSIONS];
  } catch (e) {
    return [...INITIAL_MISSIONS];
  }
}

export function saveMissions(missions: Mission[]): void {
  try {
    localStorage.setItem(MISSIONS_KEY, JSON.stringify(missions));
  } catch (e) {
    console.warn('Failed to save missions to localStorage', e);
  }
}

export function checkDailyReward(): { available: boolean; streak: number; amount: number } {
  try {
    const raw = localStorage.getItem(DAILY_KEY);
    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;

    if (!raw) {
      return { available: true, streak: 1, amount: 100 };
    }

    const { lastClaimed, streak } = JSON.parse(raw);
    const diff = now - lastClaimed;

    if (diff > oneDay * 2) {
      // Streak broken
      return { available: true, streak: 1, amount: 100 };
    } else if (diff > oneDay) {
      // Next day available
      const nextStreak = (streak % 7) + 1;
      const amounts = [100, 150, 200, 250, 300, 400, 600];
      return { available: true, streak: nextStreak, amount: amounts[nextStreak - 1] };
    } else {
      // Already claimed today
      return { available: false, streak, amount: 0 };
    }
  } catch (e) {
    return { available: true, streak: 1, amount: 100 };
  }
}

export function claimDailyReward(): number {
  const check = checkDailyReward();
  if (!check.available) return 0;

  try {
    localStorage.setItem(
      DAILY_KEY,
      JSON.stringify({
        lastClaimed: Date.now(),
        streak: check.streak,
      })
    );
  } catch (e) {
    console.warn('Failed to record daily claim', e);
  }

  return check.amount;
}
