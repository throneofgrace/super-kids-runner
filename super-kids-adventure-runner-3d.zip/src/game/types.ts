export type GameState = 'TITLE' | 'PLAYING' | 'PAUSED' | 'GAMEOVER';

export type Lane = -1 | 0 | 1; // Left (-2.4), Center (0), Right (+2.4)

export type PowerUpType = 'MAGNET' | 'SUPER_JUMP' | 'SHIELD' | 'ROCKET' | 'DOUBLE_COINS';

export interface PowerUpActive {
  type: PowerUpType;
  duration: number; // total duration in seconds
  remaining: number; // remaining in seconds
}

export interface CharacterConfig {
  id: string;
  name: string;
  title: string;
  cost: number;
  unlocked: boolean;
  shirtColor: number;
  pantsColor: number;
  hatColor: number;
  skinColor: number;
  hairColor: number;
  accessory: 'explorer_hat' | 'headphones' | 'runner_helmet' | 'dino_hoodie' | 'beanie';
  description: string;
  perk: string;
}

export interface WorldConfig {
  id: string;
  name: string;
  theme: 'jungle' | 'candy' | 'city' | 'dino' | 'snow';
  cost: number;
  unlocked: boolean;
  skyColor: number;
  fogColor: number;
  fogNear: number;
  fogFar: number;
  groundColor: number;
  trackColor: number;
  stripeColor: number;
  ambientColor: number;
  dirLightColor: number;
  description: string;
}

export type ObstacleType = 
  | 'BOX_HURDLE' // Jump over
  | 'BARREL_ROLL' // Jump over / rolling
  | 'CARTOON_CAR' // Jump over or dodge / moving
  | 'HANGING_BARRIER' // Slide under
  | 'ARCH_LOG' // Slide under
  | 'TALL_TOTEM' // Dodge left or right
  | 'DOUBLE_CRATES' // Dodge left or right
  | 'TRAFFIC_CONES'; // Jump or dodge

export interface ObstacleInstance {
  id: number;
  type: ObstacleType;
  lane: Lane;
  z: number;
  y: number;
  width: number;
  height: number;
  depth: number;
  isMoving?: boolean;
  speedZ?: number;
  requiresSlide?: boolean;
  requiresJump?: boolean;
  mesh?: any;
}

export interface CollectibleInstance {
  id: number;
  type: 'COIN' | 'GEM' | PowerUpType;
  lane: Lane;
  x: number;
  y: number;
  z: number;
  collected: boolean;
  mesh?: any;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  target: number;
  current: number;
  reward: number;
  completed: boolean;
  type: 'COINS' | 'DISTANCE' | 'JUMPS' | 'SLIDES' | 'POWERUPS';
}

export interface PlayerStats {
  coins: number;
  gems: number;
  highScore: number;
  bestDistance: number;
  runsPlayed: number;
  selectedCharacter: string;
  selectedWorld: string;
  unlockedCharacters: string[];
  unlockedWorlds: string[];
  soundEnabled: boolean;
  musicEnabled: boolean;
  showMobileControls: boolean;
}
