import * as THREE from 'three';
import { CharacterConfig, Lane, PowerUpType } from './types';
import { CharacterMeshHandle, createCharacterMesh } from './proceduralModels';
import { sounds } from './audio';

export const LANE_WIDTH = 2.4;
const GRAVITY = -42;
const JUMP_SPEED = 14.5;
const SUPER_JUMP_SPEED = 20.5;
const DIVE_SPEED = -28;
const SLIDE_DURATION = 0.75; // seconds

export class PlayerController {
  public meshHandle: CharacterMeshHandle;
  public lane: Lane = 0;
  public x = 0;
  public y = 0;
  public z = 0;
  public vy = 0;
  public isGrounded = true;
  public isSliding = false;
  public slideTimer = 0;
  public isStumbling = false;
  public stumbleTimer = 0;

  // Active power-up states
  public hasShield = false;
  public hasMagnet = false;
  public hasSuperJump = false;
  public hasRocket = false;
  public hasDoubleCoins = false;

  private runTimer = 0;
  private config: CharacterConfig;

  constructor(config: CharacterConfig) {
    this.config = config;
    this.meshHandle = createCharacterMesh(config);
  }

  public changeCharacter(newConfig: CharacterConfig) {
    this.config = newConfig;
    const parent = this.meshHandle.root.parent;
    if (parent) {
      parent.remove(this.meshHandle.root);
    }
    this.meshHandle = createCharacterMesh(newConfig);
    if (parent) {
      parent.add(this.meshHandle.root);
    }
    this.updatePosition();
  }

  public moveLeft() {
    if (this.isStumbling) return;
    if (this.lane === 1) {
      this.lane = 0;
    } else if (this.lane === 0) {
      this.lane = -1;
    }
  }

  public moveRight() {
    if (this.isStumbling) return;
    if (this.lane === -1) {
      this.lane = 0;
    } else if (this.lane === 0) {
      this.lane = 1;
    }
  }

  public jump(): boolean {
    if (this.isStumbling) return false;
    if (this.isGrounded) {
      this.vy = this.hasSuperJump ? SUPER_JUMP_SPEED : JUMP_SPEED;
      this.isGrounded = false;
      this.isSliding = false;
      this.slideTimer = 0;
      sounds.playJump();
      return true;
    }
    return false;
  }

  public slide(): boolean {
    if (this.isStumbling) return false;
    if (!this.isGrounded) {
      // Fast dive to ground from air!
      this.vy = DIVE_SPEED;
      sounds.playSlide();
      return true;
    }
    if (!this.isSliding) {
      this.isSliding = true;
      this.slideTimer = SLIDE_DURATION;
      sounds.playSlide();
      return true;
    }
    return false;
  }

  public triggerStumble() {
    this.isStumbling = true;
    this.stumbleTimer = 1.0;
    sounds.playCrash();
  }

  public reset(startingZ = 0) {
    this.lane = 0;
    this.x = 0;
    this.y = 0;
    this.z = startingZ;
    this.vy = 0;
    this.isGrounded = true;
    this.isSliding = false;
    this.slideTimer = 0;
    this.isStumbling = false;
    this.stumbleTimer = 0;
    this.hasShield = false;
    this.hasMagnet = false;
    this.hasSuperJump = false;
    this.hasRocket = false;
    this.hasDoubleCoins = false;
    this.updatePowerUpVisuals();
    this.updatePosition();
  }

  public updatePowerUpVisuals() {
    this.meshHandle.shieldBubble.visible = this.hasShield;
    this.meshHandle.magnetIcon.visible = this.hasMagnet;
    this.meshHandle.jetpack.visible = this.hasRocket;
  }

  public update(delta: number, currentSpeed: number) {
    // 1. Horizontal movement towards target lane
    const targetX = this.lane * LANE_WIDTH;
    const lerpFactor = 1 - Math.exp(-18 * delta);
    this.x += (targetX - this.x) * lerpFactor;

    // Banking tilt when switching lanes
    const dx = targetX - this.x;
    this.meshHandle.root.rotation.z = -dx * 0.12;

    // 2. Rocket boost altitude override
    if (this.hasRocket) {
      // Hover steadily at y = 1.8m
      const targetY = 1.8;
      this.y += (targetY - this.y) * lerpFactor;
      this.vy = 0;
      this.isGrounded = false;
      this.isSliding = false;
    } else {
      // Standard gravity & jumping physics
      if (!this.isGrounded) {
        this.vy += GRAVITY * delta;
        this.y += this.vy * delta;

        if (this.y <= 0) {
          this.y = 0;
          this.vy = 0;
          this.isGrounded = true;
        }
      }
    }

    // 3. Sliding timer
    if (this.isSliding) {
      this.slideTimer -= delta;
      if (this.slideTimer <= 0) {
        this.isSliding = false;
        this.slideTimer = 0;
      }
    }

    // 4. Stumble recovery
    if (this.isStumbling) {
      this.stumbleTimer -= delta;
      if (this.stumbleTimer <= 0) {
        this.isStumbling = false;
      }
    }

    // 5. Update running & skeletal animations
    this.animateLimbs(delta, currentSpeed);

    // 6. Update position
    this.updatePosition();
  }

  private animateLimbs(delta: number, speed: number) {
    const { leftLeg, rightLeg, leftArm, rightArm, head, body, shieldBubble } = this.meshHandle;

    if (this.isStumbling) {
      // Comedic wobble & spin
      body.rotation.x = 0.3;
      body.rotation.y = Math.sin(this.stumbleTimer * 20) * 0.5;
      body.position.y = 0.5;
      return;
    }

    if (this.isSliding) {
      // Crouch / tilt back for sliding under barriers
      body.position.y = 0.32;
      body.rotation.x = -0.75; // Leaned back
      body.rotation.y = 0;

      leftLeg.rotation.x = -1.2;
      rightLeg.rotation.x = -1.2;
      leftArm.rotation.x = 0.5;
      rightArm.rotation.x = 0.5;
      head.rotation.x = 0.6; // Keep looking forward
      return;
    }

    if (!this.isGrounded) {
      // Jumping / Air pose
      body.position.y = 0.75;
      body.rotation.x = 0;
      body.rotation.y = 0;

      // Legs bent slightly
      leftLeg.rotation.x = -0.4;
      rightLeg.rotation.x = 0.2;

      // Arms reaching outward/upward for balance
      leftArm.rotation.x = -1.2;
      rightArm.rotation.x = -1.2;
      leftArm.rotation.z = -0.4;
      rightArm.rotation.z = 0.4;

      head.rotation.x = -0.15;
      return;
    }

    // Running on ground
    const runFreq = speed * 0.7; // Run cadence scales with runner speed
    this.runTimer += delta * runFreq;

    const legAngle = Math.sin(this.runTimer) * 0.75;
    leftLeg.rotation.x = legAngle;
    rightLeg.rotation.x = -legAngle;

    // Arms swing in opposite phase
    leftArm.rotation.x = -legAngle * 0.9;
    rightArm.rotation.x = legAngle * 0.9;
    leftArm.rotation.z = 0.1;
    rightArm.rotation.z = -0.1;

    // Torso bounce & slight roll
    body.position.y = 0.75 + Math.abs(Math.sin(this.runTimer)) * 0.08;
    body.rotation.x = 0.08; // Slight forward aggressive running lean
    body.rotation.y = Math.sin(this.runTimer * 0.5) * 0.08;
    head.position.y = 0.48;
    head.rotation.x = 0;

    // Shield subtle pulse
    if (this.hasShield) {
      shieldBubble.rotation.y += delta * 2;
    }
  }

  private updatePosition() {
    this.meshHandle.root.position.set(this.x, this.y, this.z);
  }

  // Get current 3D bounding box for collision testing
  public getBoundingBox(): THREE.Box3 {
    // When sliding, hitbox height drops to 0.75m; when standing/jumping it is 1.6m tall
    const halfWidth = 0.4;
    const height = this.isSliding ? 0.7 : 1.6;
    const halfDepth = 0.35;

    return new THREE.Box3(
      new THREE.Vector3(this.x - halfWidth, this.y, this.z - halfDepth),
      new THREE.Vector3(this.x + halfWidth, this.y + height, this.z + halfDepth)
    );
  }
}
