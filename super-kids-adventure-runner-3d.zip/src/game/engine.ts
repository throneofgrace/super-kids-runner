import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import {
  CharacterConfig,
  GameState,
  Mission,
  PlayerStats,
  PowerUpActive,
  PowerUpType,
  WorldConfig,
} from './types';
import { CHARACTERS, WORLDS } from './worldConfig';
import { PlayerController } from './player';
import { TrackManager } from './trackManager';
import { sounds } from './audio';
import { saveMissions, savePlayerStats } from './storage';

export interface GameEngineCallbacks {
  onScoreUpdate: (score: number, coins: number, distance: number) => void;
  onPowerUpsUpdate: (powerUps: PowerUpActive[]) => void;
  onGameOver: (summary: { score: number; coins: number; distance: number; isHighScore: boolean }) => void;
  onMissionProgress: (missions: Mission[]) => void;
}

export class GameEngine {
  private container: HTMLElement;
  private callbacks: GameEngineCallbacks;

  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private dirLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;

  private isSoftwareGl = false;
  private frameId = 0;
  private isDestroyed = false;

  public state: GameState = 'TITLE';
  public stats: PlayerStats;
  public missions: Mission[];
  public currentWorld: WorldConfig;
  public currentCharacter: CharacterConfig;

  private player: PlayerController;
  private trackManager: TrackManager;

  // Run gameplay metrics
  public currentSpeed = 14.0;
  public baseSpeed = 14.0;
  public distanceRun = 0;
  public coinsCollectedThisRun = 0;
  public score = 0;
  public activePowerUps: Map<PowerUpType, PowerUpActive> = new Map();

  // Stats in current run for missions
  private jumpsThisRun = 0;
  private slidesThisRun = 0;
  private powerUpsThisRun = 0;

  // Camera damping variables
  private cameraTarget = new THREE.Vector3();
  private cameraLookTarget = new THREE.Vector3();
  private titleOrbitAngle = 0;
  private lastTime = 0;

  constructor(
    container: HTMLElement,
    stats: PlayerStats,
    missions: Mission[],
    callbacks: GameEngineCallbacks
  ) {
    this.container = container;
    this.stats = stats;
    this.missions = missions;
    this.callbacks = callbacks;

    // Pick selected world and character
    this.currentWorld =
      WORLDS.find((w) => w.id === stats.selectedWorld) || WORLDS[0];
    this.currentCharacter =
      CHARACTERS.find((c) => c.id === stats.selectedCharacter) || CHARACTERS[0];

    // Detect software WebGL
    this.isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch (e) {
        return false;
      }
    })();

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(this.currentWorld.skyColor);
    this.scene.fog = new THREE.FogExp2(this.currentWorld.fogColor, 0.015);

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(
      60,
      window.innerWidth / window.innerHeight,
      0.1,
      140
    );
    this.camera.position.set(0, 3.8, 6.5);

    // 3. Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.setPixelRatio(
      this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2)
    );
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    this.container.appendChild(this.renderer.domElement);

    // 4. Studio Environment Reflection (RoomEnvironment)
    try {
      const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
      this.scene.environment = pmremGenerator.fromScene(
        new RoomEnvironment(),
        0.04
      ).texture;
      pmremGenerator.dispose();
    } catch (e) {
      console.warn('RoomEnvironment setup error', e);
    }

    // 5. Lighting Rig
    this.dirLight = new THREE.DirectionalLight(this.currentWorld.dirLightColor, 1.8);
    this.dirLight.position.set(12, 22, 10);
    this.dirLight.castShadow = !this.isSoftwareGl;
    if (this.dirLight.shadow) {
      this.dirLight.shadow.mapSize.width = 1024;
      this.dirLight.shadow.mapSize.height = 1024;
      this.dirLight.shadow.camera.near = 0.5;
      this.dirLight.shadow.camera.far = 60;
      const d = 16;
      this.dirLight.shadow.camera.left = -d;
      this.dirLight.shadow.camera.right = d;
      this.dirLight.shadow.camera.top = d;
      this.dirLight.shadow.camera.bottom = -d;
      this.dirLight.shadow.bias = -0.0005;
      this.dirLight.shadow.normalBias = 0.02;
    }
    this.scene.add(this.dirLight);

    this.hemiLight = new THREE.HemisphereLight(
      this.currentWorld.ambientColor,
      this.currentWorld.groundColor,
      0.9
    );
    this.scene.add(this.hemiLight);

    // 6. Player & Track
    this.player = new PlayerController(this.currentCharacter);
    this.scene.add(this.player.meshHandle.root);

    this.trackManager = new TrackManager(this.scene, this.currentWorld);

    // Window resize handler
    window.addEventListener('resize', this.onResize);

    // Start render loop
    this.lastTime = performance.now();
    this.startLoop();
  }

  private onResize = () => {
    if (!this.container || this.isDestroyed) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  public selectWorld(worldId: string) {
    const world = WORLDS.find((w) => w.id === worldId);
    if (!world) return;
    this.currentWorld = world;
    this.stats.selectedWorld = worldId;
    savePlayerStats(this.stats);

    this.scene.background = new THREE.Color(world.skyColor);
    this.scene.fog = new THREE.FogExp2(world.fogColor, 0.015);
    this.dirLight.color.setHex(world.dirLightColor);
    this.hemiLight.color.setHex(world.ambientColor);
    this.hemiLight.groundColor.setHex(world.groundColor);

    this.trackManager.setWorld(world);
  }

  public selectCharacter(characterId: string) {
    const char = CHARACTERS.find((c) => c.id === characterId);
    if (!char) return;
    this.currentCharacter = char;
    this.stats.selectedCharacter = characterId;
    savePlayerStats(this.stats);

    this.player.changeCharacter(char);
  }

  public startGame() {
    this.state = 'PLAYING';
    this.distanceRun = 0;
    this.coinsCollectedThisRun = 0;
    this.score = 0;
    this.currentSpeed = this.baseSpeed;
    this.jumpsThisRun = 0;
    this.slidesThisRun = 0;
    this.powerUpsThisRun = 0;
    this.activePowerUps.clear();

    this.player.reset(0);
    this.trackManager.reset();

    sounds.startMusic();
    this.updateHUD();
  }

  public pauseGame() {
    if (this.state === 'PLAYING') {
      this.state = 'PAUSED';
      sounds.stopMusic();
    }
  }

  public resumeGame() {
    if (this.state === 'PAUSED') {
      this.state = 'PLAYING';
      this.lastTime = performance.now();
      sounds.startMusic();
    }
  }

  public returnToTitle() {
    this.state = 'TITLE';
    sounds.stopMusic();
    this.player.reset(0);
    this.trackManager.reset();
  }

  // Input actions
  public handleLeft() {
    if (this.state !== 'PLAYING') return;
    this.player.moveLeft();
  }

  public handleRight() {
    if (this.state !== 'PLAYING') return;
    this.player.moveRight();
  }

  public handleJump() {
    if (this.state !== 'PLAYING') return;
    if (this.player.jump()) {
      this.jumpsThisRun++;
      this.updateMissionProgress('JUMPS', 1);
    }
  }

  public handleSlide() {
    if (this.state !== 'PLAYING') return;
    if (this.player.slide()) {
      this.slidesThisRun++;
      this.updateMissionProgress('SLIDES', 1);
    }
  }

  private startLoop() {
    const afterDraw = (cb: () => void) => {
      const gl = this.renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (this.isDestroyed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          this.frameId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          this.frameId = window.setTimeout(cb, 80);
        }
      };
      this.frameId = window.setTimeout(poll, 5);
    };

    const tick = (now: number) => {
      if (this.isDestroyed) return;

      const rawDelta = (now - this.lastTime) / 1000;
      this.lastTime = now;
      const delta = Math.min(rawDelta, 0.05); // Clamp frame delta time

      this.update(delta);
      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        afterDraw(() => tick(performance.now()));
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    this.frameId = requestAnimationFrame(tick);
  }

  private update(delta: number) {
    if (this.state === 'TITLE') {
      this.updateTitleScreen(delta);
      return;
    }

    if (this.state !== 'PLAYING') return;

    // 1. Advance Runner Speed
    // Base speed gradually ramps with distance
    const speedBoost = Math.min(this.distanceRun / 180, 7.0);
    let targetSpeed = this.baseSpeed + speedBoost;

    // If rocket active, fly at warp speed!
    if (this.player.hasRocket) {
      targetSpeed = 26.0;
    }

    this.currentSpeed = targetSpeed;

    // 2. Advance Forward Distance (Negative Z)
    const forwardStep = this.currentSpeed * delta;
    this.player.z -= forwardStep;
    this.distanceRun += forwardStep;
    this.score += Math.floor(forwardStep * 1.5);

    // Update distance mission
    this.updateMissionProgress('DISTANCE', Math.floor(this.distanceRun), true);

    // 3. Update Player Controller
    this.player.update(delta, this.currentSpeed);

    // 4. Update Directional Light position to track player
    this.dirLight.position.z = this.player.z + 10;
    this.dirLight.target.position.z = this.player.z;
    this.dirLight.target.updateMatrixWorld();

    // 5. Update Power-Up Active Timers
    this.updatePowerUps(delta);

    // 6. Update Track Chunks & Obstacles
    const playerPos = new THREE.Vector3(this.player.x, this.player.y, this.player.z);
    this.trackManager.update(this.player.z, delta, this.player.hasMagnet, playerPos);

    // 7. Test Collisions with Obstacles
    this.checkObstacleCollisions();

    // 8. Test Collectible Pickups (Coins, Gems, Power-Ups)
    this.checkCollectiblePickups();

    // 9. Camera Following with Spring Damping
    this.updateCamera(delta);

    // 10. Update HUD Callbacks
    this.updateHUD();
  }

  private updateTitleScreen(delta: number) {
    this.titleOrbitAngle += delta * 0.4;
    const r = 4.8;
    this.camera.position.set(
      Math.sin(this.titleOrbitAngle) * r,
      2.5 + Math.sin(this.titleOrbitAngle * 2) * 0.3,
      Math.cos(this.titleOrbitAngle) * r
    );
    this.camera.lookAt(0, 1.1, 0);

    // Character gently rotates & waves in idle
    this.player.meshHandle.root.position.set(0, 0, 0);
    this.player.meshHandle.root.rotation.y = -this.titleOrbitAngle + Math.PI / 2;
    this.player.meshHandle.head.rotation.y = Math.sin(this.titleOrbitAngle * 3) * 0.2;
  }

  private updateCamera(delta: number) {
    // Target camera position: behind and slightly above player
    const desiredCamX = this.player.x * 0.35;
    const desiredCamY = Math.max(3.2, 3.2 + this.player.y * 0.4);
    const desiredCamZ = this.player.z + 5.8;

    const lerpFactor = 1 - Math.exp(-12 * delta);
    this.cameraTarget.set(desiredCamX, desiredCamY, desiredCamZ);
    this.camera.position.lerp(this.cameraTarget, lerpFactor);

    // Look slightly ahead of player
    const lookX = this.player.x * 0.25;
    const lookY = 1.2 + this.player.y * 0.2;
    const lookZ = this.player.z - 8.0;
    this.cameraLookTarget.lerp(new THREE.Vector3(lookX, lookY, lookZ), lerpFactor);
    this.camera.lookAt(this.cameraLookTarget);
  }

  private updatePowerUps(delta: number) {
    const expired: PowerUpType[] = [];

    this.activePowerUps.forEach((power, type) => {
      power.remaining -= delta;
      if (power.remaining <= 0) {
        expired.push(type);
      }
    });

    expired.forEach((type) => {
      this.activePowerUps.delete(type);
      if (type === 'MAGNET') this.player.hasMagnet = false;
      if (type === 'SUPER_JUMP') this.player.hasSuperJump = false;
      if (type === 'SHIELD') this.player.hasShield = false;
      if (type === 'ROCKET') this.player.hasRocket = false;
      if (type === 'DOUBLE_COINS') this.player.hasDoubleCoins = false;
    });

    if (expired.length > 0) {
      this.player.updatePowerUpVisuals();
    }

    this.callbacks.onPowerUpsUpdate(Array.from(this.activePowerUps.values()));
  }

  private checkObstacleCollisions() {
    if (this.state !== 'PLAYING') return;

    const playerBox = this.player.getBoundingBox();

    for (const obs of this.trackManager.activeObstacles) {
      // Fast Z-distance rejection check
      const dz = Math.abs(obs.z - this.player.z);
      if (dz > 1.2) continue;

      // Obstacle bounds
      const obsHalfW = obs.width / 2;
      const obsHalfD = obs.depth / 2;
      const obsX = obs.lane * 2.4;

      // Vertical clearance rules:
      let obsMinY = obs.y;
      let obsMaxY = obs.y + obs.height;

      if (obs.requiresSlide) {
        // Overhead hanging barrier: clear bottom space up to 1.1m
        obsMinY = 1.1;
      }

      const obsBox = new THREE.Box3(
        new THREE.Vector3(obsX - obsHalfW, obsMinY, obs.z - obsHalfD),
        new THREE.Vector3(obsX + obsHalfW, obsMaxY, obs.z + obsHalfD)
      );

      // Check intersection
      if (playerBox.intersectsBox(obsBox)) {
        // 1. Invincible Rocket Boost: smash through with zero harm!
        if (this.player.hasRocket) {
          if (obs.mesh) obs.mesh.visible = false;
          sounds.playShieldHit();
          continue;
        }

        // 2. Shield Bubble Protection: absorb the blow safely!
        if (this.player.hasShield) {
          this.player.hasShield = false;
          this.activePowerUps.delete('SHIELD');
          this.player.updatePowerUpVisuals();
          sounds.playShieldHit();
          if (obs.mesh) obs.mesh.visible = false;
          this.callbacks.onPowerUpsUpdate(Array.from(this.activePowerUps.values()));
          continue;
        }

        // 3. Collision: Game Over!
        this.triggerGameOver();
        break;
      }
    }
  }

  private checkCollectiblePickups() {
    const playerPos = new THREE.Vector3(this.player.x, this.player.y + 0.8, this.player.z);

    for (const item of this.trackManager.activeCollectibles) {
      if (item.collected) continue;

      const itemPos = new THREE.Vector3(item.x, item.y, item.z);
      const dist = playerPos.distanceTo(itemPos);

      // Collection threshold
      if (dist < 1.35) {
        item.collected = true;

        if (item.type === 'COIN') {
          const multiplier = this.player.hasDoubleCoins ? 2 : 1;
          this.coinsCollectedThisRun += multiplier;
          this.score += 25 * multiplier;
          sounds.playCoin();
          this.updateMissionProgress('COINS', multiplier);
        } else if (item.type === 'GEM') {
          this.coinsCollectedThisRun += 10;
          this.score += 250;
          sounds.playGem();
          this.updateMissionProgress('COINS', 10);
        } else {
          // Power-Up Mystery Cube!
          this.activatePowerUp(item.type);
          this.powerUpsThisRun++;
          this.updateMissionProgress('POWERUPS', 1);
        }
      }
    }
  }

  public activatePowerUp(type: PowerUpType) {
    sounds.playPowerUp();

    let duration = 8.0; // default 8 seconds
    if (type === 'ROCKET') {
      duration = this.currentCharacter.accessory === 'runner_helmet' ? 6.5 : 5.0;
    } else if (type === 'SUPER_JUMP') {
      duration = this.currentCharacter.accessory === 'beanie' ? 10.0 : 8.0;
    }

    this.activePowerUps.set(type, {
      type,
      duration,
      remaining: duration,
    });

    if (type === 'MAGNET') this.player.hasMagnet = true;
    if (type === 'SUPER_JUMP') this.player.hasSuperJump = true;
    if (type === 'SHIELD') this.player.hasShield = true;
    if (type === 'ROCKET') this.player.hasRocket = true;
    if (type === 'DOUBLE_COINS') this.player.hasDoubleCoins = true;

    this.player.updatePowerUpVisuals();
    this.callbacks.onPowerUpsUpdate(Array.from(this.activePowerUps.values()));
  }

  private updateMissionProgress(type: Mission['type'], amount: number, isAbsolute = false) {
    let updated = false;

    this.missions.forEach((m) => {
      if (!m.completed && m.type === type) {
        if (isAbsolute) {
          if (amount > m.current) {
            m.current = amount;
            updated = true;
          }
        } else {
          m.current += amount;
          updated = true;
        }

        if (m.current >= m.target) {
          m.completed = true;
          this.stats.coins += m.reward;
          sounds.playGem();
        }
      }
    });

    if (updated) {
      saveMissions(this.missions);
      savePlayerStats(this.stats);
      this.callbacks.onMissionProgress([...this.missions]);
    }
  }

  private triggerGameOver() {
    this.state = 'GAMEOVER';
    this.player.triggerStumble();
    sounds.stopMusic();

    // Update global persistent stats
    this.stats.runsPlayed++;
    this.stats.coins += this.coinsCollectedThisRun;

    const isHighScore = this.score > this.stats.highScore;
    if (isHighScore) {
      this.stats.highScore = this.score;
    }

    if (this.distanceRun > this.stats.bestDistance) {
      this.stats.bestDistance = Math.floor(this.distanceRun);
    }

    savePlayerStats(this.stats);

    this.callbacks.onGameOver({
      score: this.score,
      coins: this.coinsCollectedThisRun,
      distance: Math.floor(this.distanceRun),
      isHighScore,
    });
  }

  private updateHUD() {
    this.callbacks.onScoreUpdate(
      this.score,
      this.coinsCollectedThisRun,
      Math.floor(this.distanceRun)
    );
  }

  public destroy() {
    this.isDestroyed = true;
    window.removeEventListener('resize', this.onResize);
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    sounds.stopMusic();

    if (this.renderer) {
      this.renderer.dispose();
      if (this.container.contains(this.renderer.domElement)) {
        this.container.removeChild(this.renderer.domElement);
      }
    }
  }
}
