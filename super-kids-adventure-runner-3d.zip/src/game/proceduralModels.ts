import * as THREE from 'three';
import { CharacterConfig, ObstacleType, PowerUpType } from './types';

// Shared materials and geometries for optimal mobile performance
const materialsCache = new Map<string, THREE.Material>();

function getStandardMaterial(color: number, roughness = 0.5, metalness = 0.1, options: THREE.MeshStandardMaterialParameters = {}): THREE.MeshStandardMaterial {
  const key = `${color}_${roughness}_${metalness}_${JSON.stringify(options)}`;
  if (!materialsCache.has(key)) {
    materialsCache.set(
      key,
      new THREE.MeshStandardMaterial({
        color,
        roughness,
        metalness,
        ...options,
      })
    );
  }
  return materialsCache.get(key) as THREE.MeshStandardMaterial;
}

// -------------------------------------------------------------
// Procedural Character Builder
// -------------------------------------------------------------
export interface CharacterMeshHandle {
  root: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  head: THREE.Group;
  body: THREE.Group;
  shieldBubble: THREE.Mesh;
  jetpack: THREE.Group;
  magnetIcon: THREE.Group;
  superJumpSprings: THREE.Group;
}

export function createCharacterMesh(config: CharacterConfig): CharacterMeshHandle {
  const root = new THREE.Group();
  root.name = `character_${config.id}`;

  // Body container for squash & stretch and slides
  const body = new THREE.Group();
  body.position.y = 0.75;
  root.add(body);

  // Torso / Shirt (Primary silhouette)
  const shirtMat = getStandardMaterial(config.shirtColor, 0.6, 0.05);
  const torsoGeo = new THREE.CylinderGeometry(0.28, 0.24, 0.55, 12);
  const torsoMesh = new THREE.Mesh(torsoGeo, shirtMat);
  torsoMesh.castShadow = true;
  torsoMesh.receiveShadow = true;
  body.add(torsoMesh);

  // Shirt Collar / Accent detail
  const collarGeo = new THREE.TorusGeometry(0.18, 0.05, 8, 16);
  collarGeo.rotateX(Math.PI / 2);
  const collarMat = getStandardMaterial(0xffffff, 0.4, 0.1);
  const collar = new THREE.Mesh(collarGeo, collarMat);
  collar.position.y = 0.28;
  body.add(collar);

  // Belt / Waistband
  const beltGeo = new THREE.CylinderGeometry(0.25, 0.25, 0.08, 12);
  const beltMat = getStandardMaterial(0x212121, 0.8, 0.2);
  const belt = new THREE.Mesh(beltGeo, beltMat);
  belt.position.y = -0.25;
  body.add(belt);

  // Head Group (pivot for head bobbing)
  const head = new THREE.Group();
  head.position.y = 0.48;
  body.add(head);

  // Head Mesh (Cute rounded cartoon head)
  const skinMat = getStandardMaterial(config.skinColor, 0.7, 0.05);
  const headGeo = new THREE.SphereGeometry(0.38, 16, 16);
  headGeo.scale(1, 1.05, 0.95);
  const headMesh = new THREE.Mesh(headGeo, skinMat);
  headMesh.castShadow = true;
  head.add(headMesh);

  // Big Cute Cartoon Eyes
  const eyeWhiteMat = getStandardMaterial(0xffffff, 0.2, 0.0);
  const eyePupilMat = getStandardMaterial(0x1a237e, 0.1, 0.1); // Deep sparkling blue pupil
  const eyeSparkleMat = getStandardMaterial(0xffffff, 0.1, 0.0);

  const createEye = (xPos: number) => {
    const eyeGroup = new THREE.Group();
    eyeGroup.position.set(xPos, 0.04, 0.32);

    // Sclera
    const scleraGeo = new THREE.SphereGeometry(0.1, 12, 12);
    scleraGeo.scale(0.85, 1.1, 0.5);
    const sclera = new THREE.Mesh(scleraGeo, eyeWhiteMat);
    eyeGroup.add(sclera);

    // Pupil
    const pupilGeo = new THREE.SphereGeometry(0.065, 10, 10);
    pupilGeo.scale(0.85, 1.0, 0.4);
    const pupil = new THREE.Mesh(pupilGeo, eyePupilMat);
    pupil.position.z = 0.04;
    eyeGroup.add(pupil);

    // Cute catchlight twinkle
    const twinkleGeo = new THREE.SphereGeometry(0.025, 8, 8);
    const twinkle = new THREE.Mesh(twinkleGeo, eyeSparkleMat);
    twinkle.position.set(0.02, 0.03, 0.065);
    eyeGroup.add(twinkle);

    return eyeGroup;
  };

  head.add(createEye(-0.13));
  head.add(createEye(0.13));

  // Cute Rosy Blush Cheeks
  const cheekMat = getStandardMaterial(0xff8a80, 0.8, 0.0);
  const cheekGeo = new THREE.CircleGeometry(0.06, 12);
  const leftCheek = new THREE.Mesh(cheekGeo, cheekMat);
  leftCheek.position.set(-0.24, -0.08, 0.28);
  leftCheek.rotation.y = -0.4;
  head.add(leftCheek);

  const rightCheek = new THREE.Mesh(cheekGeo, cheekMat);
  rightCheek.position.set(0.24, -0.08, 0.28);
  rightCheek.rotation.y = 0.4;
  head.add(rightCheek);

  // Smiling Cartoon Mouth
  const smileGeo = new THREE.TorusGeometry(0.06, 0.015, 8, 12, Math.PI);
  smileGeo.rotateZ(Math.PI);
  const smileMat = getStandardMaterial(0xb71c1c, 0.5, 0.1);
  const smile = new THREE.Mesh(smileGeo, smileMat);
  smile.position.set(0, -0.12, 0.35);
  smile.rotation.x = 0.2;
  head.add(smile);

  // Hair & Head Accessories
  const hairMat = getStandardMaterial(config.hairColor, 0.8, 0.05);
  const hatMat = getStandardMaterial(config.hatColor, 0.5, 0.1);

  if (config.accessory === 'explorer_hat') {
    // Safari Hat
    const domeGeo = new THREE.SphereGeometry(0.4, 14, 10, 0, Math.PI * 2, 0, Math.PI / 2);
    const dome = new THREE.Mesh(domeGeo, hatMat);
    dome.position.y = 0.15;
    dome.castShadow = true;
    head.add(dome);

    const brimGeo = new THREE.CylinderGeometry(0.58, 0.58, 0.04, 16);
    const brim = new THREE.Mesh(brimGeo, hatMat);
    brim.position.y = 0.16;
    brim.castShadow = true;
    head.add(brim);

    // Green ribbon band
    const bandGeo = new THREE.CylinderGeometry(0.41, 0.41, 0.06, 16);
    const bandMat = getStandardMaterial(0x2e7d32, 0.5, 0.1);
    const band = new THREE.Mesh(bandGeo, bandMat);
    band.position.y = 0.2;
    head.add(band);
  } else if (config.accessory === 'headphones') {
    // Hair tufts
    const hairGeo = new THREE.SphereGeometry(0.42, 12, 12, 0, Math.PI * 2, 0, Math.PI / 2);
    const hair = new THREE.Mesh(hairGeo, hairMat);
    hair.position.y = 0.1;
    head.add(hair);

    // Headband
    const bandGeo = new THREE.TorusGeometry(0.4, 0.04, 8, 16, Math.PI);
    const band = new THREE.Mesh(bandGeo, hatMat);
    band.position.y = 0.2;
    band.rotation.x = Math.PI / 2;
    head.add(band);

    // Ear pads
    const padGeo = new THREE.CylinderGeometry(0.14, 0.14, 0.1, 12);
    padGeo.rotateZ(Math.PI / 2);
    const padMat = getStandardMaterial(0xffeb3b, 0.4, 0.2);
    const leftPad = new THREE.Mesh(padGeo, padMat);
    leftPad.position.set(-0.4, 0.05, 0);
    head.add(leftPad);

    const rightPad = new THREE.Mesh(padGeo, padMat);
    rightPad.position.set(0.4, 0.05, 0);
    head.add(rightPad);
  } else if (config.accessory === 'runner_helmet') {
    // Cyber Runner Helmet
    const helmGeo = new THREE.SphereGeometry(0.43, 16, 14);
    const helm = new THREE.Mesh(helmGeo, hatMat);
    helm.position.y = 0.1;
    helm.castShadow = true;
    head.add(helm);

    // Neon Visor
    const visorGeo = new THREE.CylinderGeometry(0.44, 0.44, 0.16, 16, 1, true, -Math.PI / 3, (2 * Math.PI) / 3);
    const visorMat = getStandardMaterial(0x00e5ff, 0.1, 0.9, { emissive: new THREE.Color(0x00b0ff), emissiveIntensity: 0.4 });
    const visor = new THREE.Mesh(visorGeo, visorMat);
    visor.position.set(0, 0.05, 0.02);
    head.add(visor);
  } else if (config.accessory === 'dino_hoodie') {
    // Dino Hoodie with soft spikes
    const hoodGeo = new THREE.SphereGeometry(0.45, 14, 14);
    const hood = new THREE.Mesh(hoodGeo, hatMat);
    hood.position.y = 0.08;
    hood.castShadow = true;
    head.add(hood);

    // Spikes down the center of the hood
    const spikeGeo = new THREE.ConeGeometry(0.08, 0.16, 4);
    const spikeMat = getStandardMaterial(0xffeb3b, 0.5, 0.1);
    for (let i = 0; i < 4; i++) {
      const spike = new THREE.Mesh(spikeGeo, spikeMat);
      const angle = 0.4 + i * 0.5;
      spike.position.set(0, Math.cos(angle) * 0.46 + 0.08, -Math.sin(angle) * 0.46);
      spike.rotation.x = -angle + Math.PI / 2;
      head.add(spike);
    }
  } else {
    // Beanie with Pom-pom
    const beanieGeo = new THREE.SphereGeometry(0.42, 14, 12, 0, Math.PI * 2, 0, Math.PI / 1.8);
    const beanie = new THREE.Mesh(beanieGeo, hatMat);
    beanie.position.y = 0.14;
    beanie.castShadow = true;
    head.add(beanie);

    // Fluffy Pom-pom
    const pomGeo = new THREE.DodecahedronGeometry(0.12, 1);
    const pomMat = getStandardMaterial(0xff5252, 0.9, 0.0);
    const pom = new THREE.Mesh(pomGeo, pomMat);
    pom.position.y = 0.56;
    head.add(pom);
  }

  // -------------------------------------------------------------
  // Limbs with Pivot Groups for Smooth Running/Jumping/Sliding
  // -------------------------------------------------------------
  const sleeveMat = shirtMat;
  const pantsMat = getStandardMaterial(config.pantsColor, 0.7, 0.05);
  const shoeMat = getStandardMaterial(0xffffff, 0.4, 0.1);
  const soleMat = getStandardMaterial(0xff3d00, 0.6, 0.05);

  const createArm = (isLeft: boolean) => {
    const armGroup = new THREE.Group();
    const xPos = isLeft ? -0.36 : 0.36;
    armGroup.position.set(xPos, 0.22, 0);

    // Shoulder / Upper sleeve
    const sleeveGeo = new THREE.SphereGeometry(0.11, 10, 10);
    const sleeve = new THREE.Mesh(sleeveGeo, sleeveMat);
    armGroup.add(sleeve);

    // Arm Limb
    const armGeo = new THREE.CylinderGeometry(0.08, 0.07, 0.35, 10);
    armGeo.translate(0, -0.175, 0);
    const armMesh = new THREE.Mesh(armGeo, skinMat);
    armMesh.castShadow = true;
    armGroup.add(armMesh);

    // Hand mitten
    const handGeo = new THREE.SphereGeometry(0.09, 10, 10);
    handGeo.translate(0, -0.38, 0);
    const hand = new THREE.Mesh(handGeo, skinMat);
    armGroup.add(hand);

    return armGroup;
  };

  const leftArm = createArm(true);
  const rightArm = createArm(false);
  body.add(leftArm);
  body.add(rightArm);

  const createLeg = (isLeft: boolean) => {
    const legGroup = new THREE.Group();
    const xPos = isLeft ? -0.15 : 0.15;
    legGroup.position.set(xPos, -0.28, 0);

    // Leg Pants
    const legGeo = new THREE.CylinderGeometry(0.11, 0.09, 0.45, 10);
    legGeo.translate(0, -0.225, 0);
    const legMesh = new THREE.Mesh(legGeo, pantsMat);
    legMesh.castShadow = true;
    legMesh.receiveShadow = true;
    legGroup.add(legMesh);

    // Sneaker
    const shoeGeo = new THREE.BoxGeometry(0.16, 0.12, 0.28);
    shoeGeo.translate(0, -0.46, 0.04);
    const shoe = new THREE.Mesh(shoeGeo, shoeMat);
    shoe.castShadow = true;
    legGroup.add(shoe);

    // Colored Sneaker Sole
    const soleGeo = new THREE.BoxGeometry(0.17, 0.04, 0.3);
    soleGeo.translate(0, -0.52, 0.04);
    const sole = new THREE.Mesh(soleGeo, soleMat);
    legGroup.add(sole);

    return legGroup;
  };

  const leftLeg = createLeg(true);
  const rightLeg = createLeg(false);
  body.add(leftLeg);
  body.add(rightLeg);

  // -------------------------------------------------------------
  // Power-Up Visual Attachments
  // -------------------------------------------------------------
  // 1. Bubble Shield
  const shieldGeo = new THREE.SphereGeometry(0.95, 20, 20);
  const shieldMat = new THREE.MeshStandardMaterial({
    color: 0x00e5ff,
    transparent: true,
    opacity: 0.4,
    roughness: 0.1,
    metalness: 0.2,
    emissive: new THREE.Color(0x0091ea),
    emissiveIntensity: 0.5,
    depthWrite: false,
  });
  const shieldBubble = new THREE.Mesh(shieldGeo, shieldMat);
  shieldBubble.position.set(0, 0.15, 0);
  shieldBubble.visible = false;
  body.add(shieldBubble);

  // 2. Rocket Boost Jetpack
  const jetpack = new THREE.Group();
  jetpack.position.set(0, 0.05, -0.28);
  jetpack.visible = false;

  const rocketGeo = new THREE.CylinderGeometry(0.09, 0.09, 0.42, 10);
  const rocketMat = getStandardMaterial(0xff1744, 0.3, 0.4);
  const leftRocket = new THREE.Mesh(rocketGeo, rocketMat);
  leftRocket.position.x = -0.14;
  jetpack.add(leftRocket);

  const rightRocket = new THREE.Mesh(rocketGeo, rocketMat);
  rightRocket.position.x = 0.14;
  jetpack.add(rightRocket);

  // Jetpack thruster flames
  const flameGeo = new THREE.ConeGeometry(0.08, 0.25, 8);
  flameGeo.rotateX(Math.PI);
  const flameMat = new THREE.MeshBasicMaterial({ color: 0xffeb3b });
  const leftFlame = new THREE.Mesh(flameGeo, flameMat);
  leftFlame.position.set(-0.14, -0.28, 0);
  jetpack.add(leftFlame);

  const rightFlame = new THREE.Mesh(flameGeo, flameMat);
  rightFlame.position.set(0.14, -0.28, 0);
  jetpack.add(rightFlame);
  body.add(jetpack);

  // 3. Floating Magnet Indicator
  const magnetIcon = new THREE.Group();
  magnetIcon.position.set(0, 0.65, 0);
  magnetIcon.visible = false;

  const magnetGeo = new THREE.TorusGeometry(0.18, 0.05, 8, 16, Math.PI);
  const magnetMat = getStandardMaterial(0xff1744, 0.3, 0.7);
  const magnetMesh = new THREE.Mesh(magnetGeo, magnetMat);
  magnetIcon.add(magnetMesh);

  const tipGeo = new THREE.BoxGeometry(0.1, 0.08, 0.08);
  const tipMat = getStandardMaterial(0xe0e0e0, 0.2, 0.8);
  const leftTip = new THREE.Mesh(tipGeo, tipMat);
  leftTip.position.set(-0.18, -0.05, 0);
  magnetIcon.add(leftTip);

  const rightTip = new THREE.Mesh(tipGeo, tipMat);
  rightTip.position.set(0.18, -0.05, 0);
  magnetIcon.add(rightTip);
  head.add(magnetIcon);

  // 4. Super Jump Springs on shoes
  const superJumpSprings = new THREE.Group();
  superJumpSprings.visible = false;
  body.add(superJumpSprings);

  // Subtle contact shadow grounding disc directly beneath player
  const shadowGeo = new THREE.CircleGeometry(0.48, 16);
  shadowGeo.rotateX(-Math.PI / 2);
  const shadowMat = new THREE.MeshBasicMaterial({
    color: 0x000000,
    transparent: true,
    opacity: 0.35,
    depthWrite: false,
  });
  const contactShadow = new THREE.Mesh(shadowGeo, shadowMat);
  contactShadow.position.y = 0.02;
  root.add(contactShadow);

  return {
    root,
    leftLeg,
    rightLeg,
    leftArm,
    rightArm,
    head,
    body,
    shieldBubble,
    jetpack,
    magnetIcon,
    superJumpSprings,
  };
}

// -------------------------------------------------------------
// Procedural Collectibles: Coins, Gems, Power-Up Mystery Boxes
// -------------------------------------------------------------
export function createCoinMesh(): THREE.Group {
  const coinGroup = new THREE.Group();

  // Beveled golden cylinder
  const coinGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.1, 16);
  coinGeo.rotateX(Math.PI / 2);
  const coinMat = getStandardMaterial(0xffd700, 0.2, 0.85);
  const coin = new THREE.Mesh(coinGeo, coinMat);
  coin.castShadow = true;
  coinGroup.add(coin);

  // Embossed center star / rim
  const rimGeo = new THREE.TorusGeometry(0.3, 0.03, 8, 16);
  const rimMat = getStandardMaterial(0xffb300, 0.15, 0.9);
  const rim = new THREE.Mesh(rimGeo, rimMat);
  rim.position.z = 0.055;
  coinGroup.add(rim);

  const rimBack = rim.clone();
  rimBack.position.z = -0.055;
  coinGroup.add(rimBack);

  return coinGroup;
}

export function createGemMesh(): THREE.Group {
  const gemGroup = new THREE.Group();

  // Sparkling octahedral crystal
  const gemGeo = new THREE.OctahedronGeometry(0.42, 0);
  gemGeo.scale(0.9, 1.4, 0.9);
  const gemMat = new THREE.MeshStandardMaterial({
    color: 0xe040fb, // Brilliant magenta violet
    roughness: 0.1,
    metalness: 0.1,
    emissive: new THREE.Color(0x7c4dff),
    emissiveIntensity: 0.4,
  });
  const gem = new THREE.Mesh(gemGeo, gemMat);
  gem.castShadow = true;
  gemGroup.add(gem);

  return gemGroup;
}

export function createPowerUpMesh(type: PowerUpType): THREE.Group {
  const group = new THREE.Group();

  let boxColor = 0xff1744; // Rocket Red
  if (type === 'SHIELD') boxColor = 0x00e5ff; // Shield Blue
  if (type === 'MAGNET') boxColor = 0xffd600; // Magnet Gold
  if (type === 'SUPER_JUMP') boxColor = 0x00e676; // Spring Green
  if (type === 'DOUBLE_COINS') boxColor = 0xaa00ff; // 2X Purple

  // Glowing question/mystery cube
  const boxGeo = new THREE.BoxGeometry(0.65, 0.65, 0.65);
  const boxMat = new THREE.MeshStandardMaterial({
    color: boxColor,
    roughness: 0.2,
    metalness: 0.4,
    emissive: new THREE.Color(boxColor),
    emissiveIntensity: 0.5,
  });
  const box = new THREE.Mesh(boxGeo, boxMat);
  box.castShadow = true;
  group.add(box);

  // Outer wireframe halo ring
  const ringGeo = new THREE.TorusGeometry(0.55, 0.04, 8, 16);
  ringGeo.rotateX(Math.PI / 4);
  const ringMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const ring = new THREE.Mesh(ringGeo, ringMat);
  group.add(ring);

  return group;
}

// -------------------------------------------------------------
// Procedural Obstacles
// -------------------------------------------------------------
export function createObstacleMesh(type: ObstacleType, theme: string): THREE.Group {
  const group = new THREE.Group();

  switch (type) {
    case 'BOX_HURDLE': {
      // Stack of rustic wooden crates with planks and braces
      const woodMat = getStandardMaterial(0xa1887f, 0.8, 0.05);
      const ironMat = getStandardMaterial(0x424242, 0.4, 0.6);

      const crateGeo = new THREE.BoxGeometry(1.6, 0.75, 0.8);
      const crate = new THREE.Mesh(crateGeo, woodMat);
      crate.position.y = 0.375;
      crate.castShadow = true;
      crate.receiveShadow = true;
      group.add(crate);

      // Metal corner bands
      const bandGeo = new THREE.BoxGeometry(1.64, 0.1, 0.84);
      const bandTop = new THREE.Mesh(bandGeo, ironMat);
      bandTop.position.y = 0.68;
      group.add(bandTop);

      const bandBottom = new THREE.Mesh(bandGeo, ironMat);
      bandBottom.position.y = 0.1;
      group.add(bandBottom);
      break;
    }

    case 'BARREL_ROLL': {
      // Cartoon rolling barrel
      const barrelMat = getStandardMaterial(theme === 'candy' ? 0xff4081 : 0x795548, 0.7, 0.1);
      const hoopMat = getStandardMaterial(0xffd54f, 0.3, 0.7);

      const bodyGeo = new THREE.CylinderGeometry(0.48, 0.48, 1.4, 14);
      bodyGeo.rotateZ(Math.PI / 2);
      const body = new THREE.Mesh(bodyGeo, barrelMat);
      body.position.y = 0.48;
      body.castShadow = true;
      group.add(body);

      // Hoops
      const hoopGeo = new THREE.TorusGeometry(0.49, 0.04, 8, 16);
      hoopGeo.rotateY(Math.PI / 2);
      const hoop1 = new THREE.Mesh(hoopGeo, hoopMat);
      hoop1.position.set(-0.4, 0.48, 0);
      group.add(hoop1);

      const hoop2 = new THREE.Mesh(hoopGeo, hoopMat);
      hoop2.position.set(0.4, 0.48, 0);
      group.add(hoop2);
      break;
    }

    case 'CARTOON_CAR': {
      // Friendly cartoon car (or mini jungle buggy / dino kart)
      const carMat = getStandardMaterial(theme === 'candy' ? 0x00e5ff : 0xffeb3b, 0.3, 0.2);
      const wheelMat = getStandardMaterial(0x212121, 0.9, 0.1);
      const glassMat = getStandardMaterial(0x81d4fa, 0.1, 0.8);

      // Chassis
      const chassisGeo = new THREE.BoxGeometry(1.5, 0.45, 1.8);
      const chassis = new THREE.Mesh(chassisGeo, carMat);
      chassis.position.y = 0.4;
      chassis.castShadow = true;
      group.add(chassis);

      // Cabin
      const cabinGeo = new THREE.BoxGeometry(1.2, 0.5, 1.0);
      const cabin = new THREE.Mesh(cabinGeo, glassMat);
      cabin.position.set(0, 0.75, -0.1);
      cabin.castShadow = true;
      group.add(cabin);

      // Wheels
      const wheelGeo = new THREE.CylinderGeometry(0.24, 0.24, 0.16, 12);
      wheelGeo.rotateZ(Math.PI / 2);
      const wheelPositions = [
        [-0.75, 0.24, 0.55],
        [0.75, 0.24, 0.55],
        [-0.75, 0.24, -0.55],
        [0.75, 0.24, -0.55],
      ];
      wheelPositions.forEach(([x, y, z]) => {
        const wheel = new THREE.Mesh(wheelGeo, wheelMat);
        wheel.position.set(x, y, z);
        wheel.castShadow = true;
        group.add(wheel);
      });
      break;
    }

    case 'HANGING_BARRIER':
    case 'ARCH_LOG': {
      // Overhead barrier: clear space below for sliding (~1.0m clearance)
      const frameMat = getStandardMaterial(theme === 'candy' ? 0xff80ab : 0x5d4037, 0.7, 0.1);
      const signMat = getStandardMaterial(theme === 'candy' ? 0xffeb3b : 0xff5722, 0.4, 0.2);

      // Left and right support posts
      const postGeo = new THREE.CylinderGeometry(0.12, 0.14, 2.8, 10);
      const leftPost = new THREE.Mesh(postGeo, frameMat);
      leftPost.position.set(-1.1, 1.4, 0);
      leftPost.castShadow = true;
      group.add(leftPost);

      const rightPost = new THREE.Mesh(postGeo, frameMat);
      rightPost.position.set(1.1, 1.4, 0);
      rightPost.castShadow = true;
      group.add(rightPost);

      // Overhead crossbeam (hanging bar)
      const beamGeo = new THREE.BoxGeometry(2.4, 0.65, 0.35);
      const beam = new THREE.Mesh(beamGeo, signMat);
      beam.position.set(0, 1.7, 0);
      beam.castShadow = true;
      group.add(beam);

      // Warning hazard stripes / candy swirls on the crossbeam
      const stripeGeo = new THREE.BoxGeometry(0.18, 0.66, 0.37);
      const stripeMat = getStandardMaterial(0xffffff, 0.3, 0.1);
      for (let i = -4; i <= 4; i += 2) {
        const stripe = new THREE.Mesh(stripeGeo, stripeMat);
        stripe.position.set(i * 0.25, 1.7, 0);
        group.add(stripe);
      }
      break;
    }

    case 'TALL_TOTEM': {
      // Tall obstacle blocking lane completely (requires lane switch)
      const totemMat = getStandardMaterial(theme === 'dino' ? 0xd84315 : 0x6d4c41, 0.8, 0.1);
      const decoMat = getStandardMaterial(theme === 'dino' ? 0xffab00 : 0x00e676, 0.5, 0.2);

      const bodyGeo = new THREE.CylinderGeometry(0.5, 0.6, 3.2, 12);
      const body = new THREE.Mesh(bodyGeo, totemMat);
      body.position.y = 1.6;
      body.castShadow = true;
      group.add(body);

      // Carved rings / features
      for (let i = 0; i < 3; i++) {
        const ringGeo = new THREE.TorusGeometry(0.55, 0.08, 8, 14);
        ringGeo.rotateX(Math.PI / 2);
        const ring = new THREE.Mesh(ringGeo, decoMat);
        ring.position.y = 0.8 + i * 0.9;
        group.add(ring);
      }
      break;
    }

    case 'DOUBLE_CRATES': {
      // 2 tall stacked crates blocking lane
      const woodMat = getStandardMaterial(0x8d6e63, 0.8, 0.05);
      const crate1 = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.3, 1.0), woodMat);
      crate1.position.y = 0.65;
      crate1.castShadow = true;
      group.add(crate1);

      const crate2 = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.3, 0.9), woodMat);
      crate2.position.y = 1.95;
      crate2.castShadow = true;
      group.add(crate2);
      break;
    }

    case 'TRAFFIC_CONES':
    default: {
      // Cluster of 2 bright warning cones
      const coneGeo = new THREE.ConeGeometry(0.25, 0.7, 10);
      const coneMat = getStandardMaterial(0xff6d00, 0.5, 0.1);
      const stripeMat = getStandardMaterial(0xffffff, 0.3, 0.1);

      const c1 = new THREE.Mesh(coneGeo, coneMat);
      c1.position.set(-0.35, 0.35, 0);
      c1.castShadow = true;
      group.add(c1);

      const s1 = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.15, 10), stripeMat);
      s1.position.set(-0.35, 0.35, 0);
      group.add(s1);

      const c2 = new THREE.Mesh(coneGeo, coneMat);
      c2.position.set(0.35, 0.35, 0.15);
      c2.castShadow = true;
      group.add(c2);

      const s2 = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.15, 10), stripeMat);
      s2.position.set(0.35, 0.35, 0.15);
      group.add(s2);
      break;
    }
  }

  return group;
}

// -------------------------------------------------------------
// Procedural Environment Props (Foliage, Buildings, Scenery)
// -------------------------------------------------------------
export function createEnvironmentProp(theme: string, side: 'left' | 'right'): THREE.Group {
  const group = new THREE.Group();

  switch (theme) {
    case 'jungle': {
      // Lush tropical palm tree or giant mushroom
      if (Math.random() > 0.4) {
        // Palm tree
        const trunkMat = getStandardMaterial(0x6d4c41, 0.9, 0.05);
        const trunkGeo = new THREE.CylinderGeometry(0.2, 0.35, 4.5, 8);
        const trunk = new THREE.Mesh(trunkGeo, trunkMat);
        trunk.position.y = 2.25;
        trunk.rotation.z = side === 'left' ? -0.1 : 0.1;
        trunk.castShadow = true;
        group.add(trunk);

        // Canopy fronds
        const leafMat = getStandardMaterial(0x2e7d32, 0.7, 0.05);
        const leafGeo = new THREE.SphereGeometry(1.6, 8, 8);
        leafGeo.scale(1.2, 0.4, 1.2);
        const canopy = new THREE.Mesh(leafGeo, leafMat);
        canopy.position.set(side === 'left' ? -0.3 : 0.3, 4.4, 0);
        canopy.castShadow = true;
        group.add(canopy);
      } else {
        // Giant fantasy mushroom
        const stemMat = getStandardMaterial(0xfff8e1, 0.8, 0.05);
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.4, 2.2, 8), stemMat);
        stem.position.y = 1.1;
        group.add(stem);

        const capMat = getStandardMaterial(0xe53935, 0.5, 0.1);
        const capGeo = new THREE.SphereGeometry(1.2, 10, 8, 0, Math.PI * 2, 0, Math.PI / 2);
        const cap = new THREE.Mesh(capGeo, capMat);
        cap.position.y = 2.0;
        cap.castShadow = true;
        group.add(cap);

        // White mushroom dots
        const dotMat = getStandardMaterial(0xffffff, 0.4, 0.05);
        for (let i = 0; i < 4; i++) {
          const dot = new THREE.Mesh(new THREE.SphereGeometry(0.18, 6, 6), dotMat);
          const angle = (i * Math.PI) / 2;
          dot.position.set(Math.cos(angle) * 0.8, 2.5, Math.sin(angle) * 0.8);
          group.add(dot);
        }
      }
      break;
    }

    case 'candy': {
      // Swirl lollipop tree or cupcake hill
      if (Math.random() > 0.5) {
        // Lollipop tree
        const stickMat = getStandardMaterial(0xffffff, 0.4, 0.1);
        const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 3.8, 8), stickMat);
        stick.position.y = 1.9;
        group.add(stick);

        const candyMat = getStandardMaterial(0xff4081, 0.2, 0.4);
        const candyGeo = new THREE.CylinderGeometry(1.2, 1.2, 0.3, 16);
        candyGeo.rotateZ(Math.PI / 2);
        const candy = new THREE.Mesh(candyGeo, candyMat);
        candy.position.y = 3.6;
        candy.castShadow = true;
        group.add(candy);

        // Inner swirl ring
        const swirlMat = getStandardMaterial(0xffeb3b, 0.2, 0.4);
        const swirl = new THREE.Mesh(new THREE.TorusGeometry(0.7, 0.12, 8, 16), swirlMat);
        swirl.position.y = 3.6;
        swirl.rotation.y = Math.PI / 2;
        group.add(swirl);
      } else {
        // Frosted cupcake
        const baseMat = getStandardMaterial(0x8d6e63, 0.8, 0.05);
        const base = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 0.7, 1.2, 10), baseMat);
        base.position.y = 0.6;
        group.add(base);

        const frostingMat = getStandardMaterial(0x80d8ff, 0.4, 0.1);
        const frosting = new THREE.Mesh(new THREE.SphereGeometry(1.1, 10, 8, 0, Math.PI * 2, 0, Math.PI / 2), frostingMat);
        frosting.position.y = 1.2;
        frosting.castShadow = true;
        group.add(frosting);

        // Cherry on top
        const cherryMat = getStandardMaterial(0xd50000, 0.2, 0.6);
        const cherry = new THREE.Mesh(new THREE.SphereGeometry(0.24, 8, 8), cherryMat);
        cherry.position.y = 2.25;
        group.add(cherry);
      }
      break;
    }

    case 'city': {
      // Cartoon Skyscraper
      const colors = [0x42a5f5, 0x26a69a, 0xab47bc, 0xff7043];
      const bColor = colors[Math.floor(Math.random() * colors.length)];
      const height = 5.0 + Math.random() * 4.0;
      const bMat = getStandardMaterial(bColor, 0.4, 0.2);

      const building = new THREE.Mesh(new THREE.BoxGeometry(2.6, height, 2.6), bMat);
      building.position.y = height / 2;
      building.castShadow = true;
      group.add(building);

      // Windows grid
      const winMat = getStandardMaterial(0xfff59d, 0.1, 0.8, { emissive: new THREE.Color(0xffeb3b), emissiveIntensity: 0.3 });
      for (let y = 1.2; y < height - 0.8; y += 1.2) {
        const win = new THREE.Mesh(new THREE.BoxGeometry(2.65, 0.4, 1.6), winMat);
        win.position.y = y;
        group.add(win);
      }
      break;
    }

    case 'dino': {
      // Volcanic rock outcrop with glowing magma fissure
      const rockMat = getStandardMaterial(0x3e2723, 0.9, 0.1);
      const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(1.6, 0), rockMat);
      rock.position.y = 1.2;
      rock.scale.set(1, 1.6, 1);
      rock.castShadow = true;
      group.add(rock);

      const magmaMat = new THREE.MeshBasicMaterial({ color: 0xff3d00 });
      const fissure = new THREE.Mesh(new THREE.BoxGeometry(1.65, 0.25, 0.25), magmaMat);
      fissure.position.y = 1.4;
      group.add(fissure);
      break;
    }

    case 'snow':
    default: {
      // Snow-capped pine tree or happy snowman
      if (Math.random() > 0.4) {
        // Pine tree with snow tiers
        const trunkMat = getStandardMaterial(0x4e342e, 0.9, 0.05);
        const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.25, 1.6, 8), trunkMat);
        trunk.position.y = 0.8;
        group.add(trunk);

        const pineMat = getStandardMaterial(0x1b5e20, 0.8, 0.05);
        const snowMat = getStandardMaterial(0xffffff, 0.6, 0.05);

        for (let i = 0; i < 3; i++) {
          const r = 1.4 - i * 0.35;
          const cone = new THREE.Mesh(new THREE.ConeGeometry(r, 1.3, 8), pineMat);
          cone.position.y = 1.8 + i * 0.9;
          cone.castShadow = true;
          group.add(cone);

          // Snow cap on cone
          const snowCap = new THREE.Mesh(new THREE.ConeGeometry(r * 0.5, 0.5, 8), snowMat);
          snowCap.position.y = 2.2 + i * 0.9;
          group.add(snowCap);
        }
      } else {
        // Cute snowman
        const snowMat = getStandardMaterial(0xffffff, 0.5, 0.05);
        const bottom = new THREE.Mesh(new THREE.SphereGeometry(1.0, 10, 10), snowMat);
        bottom.position.y = 0.8;
        group.add(bottom);

        const head = new THREE.Mesh(new THREE.SphereGeometry(0.65, 10, 10), snowMat);
        head.position.y = 2.1;
        group.add(head);

        // Carrot nose
        const carrotMat = getStandardMaterial(0xff6d00, 0.5, 0.1);
        const carrotGeo = new THREE.ConeGeometry(0.1, 0.35, 6);
        carrotGeo.rotateX(Math.PI / 2);
        const carrot = new THREE.Mesh(carrotGeo, carrotMat);
        carrot.position.set(0, 2.1, 0.65);
        group.add(carrot);

        // Scarf
        const scarfMat = getStandardMaterial(0xd50000, 0.7, 0.05);
        const scarf = new THREE.Mesh(new THREE.TorusGeometry(0.55, 0.1, 8, 14), scarfMat);
        scarf.position.y = 1.6;
        scarf.rotation.x = Math.PI / 2;
        group.add(scarf);
      }
      break;
    }
  }

  return group;
}
