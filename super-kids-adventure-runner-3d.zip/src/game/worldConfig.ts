import { CharacterConfig, WorldConfig } from './types';

export const WORLDS: WorldConfig[] = [
  {
    id: 'jungle',
    name: 'Magical Jungle',
    theme: 'jungle',
    cost: 0,
    unlocked: true,
    skyColor: 0x4dd0e1, // Bright tropical cyan sky
    fogColor: 0x64b5f6,
    fogNear: 25,
    fogFar: 85,
    groundColor: 0x2e7d32, // Lush grass
    trackColor: 0x8d6e63, // Ancient stone trail
    stripeColor: 0xa1887f,
    ambientColor: 0xffffff,
    dirLightColor: 0xfff9c4, // Warm tropical sun
    description: 'Lush tropical trees, ancient stone bridges, tiki totems, and gentle fireflies.',
  },
  {
    id: 'candy',
    name: 'Candy Wonderland',
    theme: 'candy',
    cost: 250,
    unlocked: false,
    skyColor: 0xf8bbd0, // Soft pastel pink sky
    fogColor: 0xf48fb1,
    fogNear: 25,
    fogFar: 80,
    groundColor: 0xfce4ec, // Frosting icing ground
    trackColor: 0xd81b60, // Strawberry licorice track
    stripeColor: 0xffffff, // White icing stripes
    ambientColor: 0xffffff,
    dirLightColor: 0xffecb3,
    description: 'Giant lollipop trees, candy cane hurdles, cupcakes, and chocolate wafer bridges.',
  },
  {
    id: 'city',
    name: 'Cartoon City',
    theme: 'city',
    cost: 500,
    unlocked: false,
    skyColor: 0x81d4fa, // Vibrant clean city sky
    fogColor: 0x4fc3f7,
    fogNear: 28,
    fogFar: 90,
    groundColor: 0x78909c, // Sidewalk concrete
    trackColor: 0x37474f, // Asphalt road
    stripeColor: 0xffeb3b, // Yellow road dividers
    ambientColor: 0xffffff,
    dirLightColor: 0xfff59d,
    description: 'Colorful skyscrapers, friendly cartoon cars, neon billboards, and traffic cones.',
  },
  {
    id: 'dino',
    name: 'Dino Island',
    theme: 'dino',
    cost: 800,
    unlocked: false,
    skyColor: 0xffb74d, // Sunset amber prehistoric sky
    fogColor: 0xff9800,
    fogNear: 25,
    fogFar: 85,
    groundColor: 0xbf360c, // Volcanic terracotta ground
    trackColor: 0x5d4037, // Prehistoric stone trail
    stripeColor: 0xff7043, // Glowing magma crack
    ambientColor: 0xfff3e0,
    dirLightColor: 0xffe082,
    description: 'Prehistoric palm groves, glowing volcanic rocks, and funny baby dinosaur barriers.',
  },
  {
    id: 'snow',
    name: 'Snowy Peak',
    theme: 'snow',
    cost: 1200,
    unlocked: false,
    skyColor: 0xb3e5fc, // Crisp ice blue sky
    fogColor: 0x90caf9,
    fogNear: 25,
    fogFar: 85,
    groundColor: 0xe1f5fe, // Snow blanket
    trackColor: 0x80deea, // Frozen blue glacial ice track
    stripeColor: 0xffffff, // Powder snow stripe
    ambientColor: 0xf5f5f5,
    dirLightColor: 0xffffff,
    description: 'Snowy evergreen pines, smiling snowmen, icy bridges, and rolling snowballs.',
  },
];

export const CHARACTERS: CharacterConfig[] = [
  {
    id: 'leo',
    name: 'Leo',
    title: 'Jungle Explorer',
    cost: 0,
    unlocked: true,
    shirtColor: 0x43a047, // Forest green
    pantsColor: 0x8d6e63, // Explorer khaki
    hatColor: 0xd7ccc8, // Safari hat
    skinColor: 0xffcc80,
    hairColor: 0x5d4037,
    accessory: 'explorer_hat',
    description: 'Always prepared with his safari hat and boundless courage!',
    perk: 'Balanced speed & agility',
  },
  {
    id: 'mia',
    name: 'Mia',
    title: 'Candy Pop Star',
    cost: 200,
    unlocked: false,
    shirtColor: 0xff4081, // Bubblegum pink
    pantsColor: 0x7c4dff, // Violet leggings
    hatColor: 0x00e676, // Neon headphones
    skinColor: 0xffe0b2,
    hairColor: 0xff80ab,
    accessory: 'headphones',
    description: 'Runs to the beat of upbeat pop songs with her DJ headphones!',
    perk: '+10% coin attraction radius',
  },
  {
    id: 'toby',
    name: 'Turbo Toby',
    title: 'Cyber Speeder',
    cost: 450,
    unlocked: false,
    shirtColor: 0x00bcd4, // Cyan racer
    pantsColor: 0x263238, // Carbon black
    hatColor: 0xffeb3b, // Golden visor helmet
    skinColor: 0xffcc80,
    hairColor: 0x212121,
    accessory: 'runner_helmet',
    description: 'Equipped with a streamlined racer helmet and cyber sneakers!',
    perk: '+15% longer Rocket Boost duration',
  },
  {
    id: 'rexy',
    name: 'Rexy Kid',
    title: 'Dino Roarer',
    cost: 750,
    unlocked: false,
    shirtColor: 0x66bb6a, // Dino green hoodie
    pantsColor: 0x388e3c,
    hatColor: 0x81c784, // Dino teeth hood
    skinColor: 0xffe082,
    hairColor: 0x4e342e,
    accessory: 'dino_hoodie',
    description: 'Wears a super soft dino hoodie with tail and tiny soft teeth!',
    perk: 'Extra resilience from stumbles',
  },
  {
    id: 'penny',
    name: 'Penny',
    title: 'Polar Skater',
    cost: 1100,
    unlocked: false,
    shirtColor: 0xe53935, // Cozy winter red puffer
    pantsColor: 0x1565c0, // Winter denim
    hatColor: 0xffffff, // Pom-pom beanie
    skinColor: 0xffe0b2,
    hairColor: 0xffb300,
    accessory: 'beanie',
    description: 'Ready for snow drifts with her warm pom-pom beanie and mittens!',
    perk: '+20% longer Super Jump float',
  },
];
