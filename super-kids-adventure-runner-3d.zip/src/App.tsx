import React, { useEffect, useRef, useState } from 'react';
import confetti from 'canvas-confetti';
import { GameEngine } from './game/engine';
import {
  CharacterConfig,
  GameState,
  Mission,
  PlayerStats,
  PowerUpActive,
  WorldConfig,
} from './game/types';
import {
  claimDailyReward,
  loadMissions,
  loadPlayerStats,
  savePlayerStats,
} from './game/storage';
import { CHARACTERS, WORLDS } from './game/worldConfig';
import { sounds } from './game/audio';
import { TitleScreen } from './components/TitleScreen';
import { GameHUD } from './components/GameHUD';
import { CharacterSelectModal } from './components/CharacterSelectModal';
import { WorldSelectModal } from './components/WorldSelectModal';
import { MissionsModal } from './components/MissionsModal';
import { GameOverModal } from './components/GameOverModal';
import { SettingsModal } from './components/SettingsModal';
import { InstallModal } from './components/InstallModal';

export default function App() {
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Persistent Player Stats & Missions
  const [stats, setStats] = useState<PlayerStats>(() => loadPlayerStats());
  const [missions, setMissions] = useState<Mission[]>(() => loadMissions());

  // Game UI state
  const [gameState, setGameState] = useState<GameState>('TITLE');
  const [score, setScore] = useState(0);
  const [coinsThisRun, setCoinsThisRun] = useState(0);
  const [distance, setDistance] = useState(0);
  const [activePowerUps, setActivePowerUps] = useState<PowerUpActive[]>([]);

  // Modals state
  const [isCharModalOpen, setIsCharModalOpen] = useState(false);
  const [isWorldModalOpen, setIsWorldModalOpen] = useState(false);
  const [isMissionsModalOpen, setIsMissionsModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);

  // Game over modal state
  const [gameOverData, setGameOverData] = useState<{
    score: number;
    coins: number;
    distance: number;
    isHighScore: boolean;
  } | null>(null);

  // Daily gift notification banner
  const [dailyClaimToast, setDailyClaimToast] = useState<string | null>(null);

  // Initialize Game Engine on Mount
  useEffect(() => {
    if (!canvasContainerRef.current) return;

    sounds.setSoundEnabled(stats.soundEnabled);
    sounds.setMusicEnabled(stats.musicEnabled);

    const engine = new GameEngine(canvasContainerRef.current, stats, missions, {
      onScoreUpdate: (s, c, d) => {
        setScore(s);
        setCoinsThisRun(c);
        setDistance(d);
      },
      onPowerUpsUpdate: (powerUps) => {
        setActivePowerUps(powerUps);
      },
      onGameOver: (summary) => {
        setGameState('GAMEOVER');
        setGameOverData(summary);
        setStats({ ...engine.stats });
      },
      onMissionProgress: (updatedMissions) => {
        setMissions(updatedMissions);
        setStats({ ...engine.stats });
      },
    });

    engineRef.current = engine;

    return () => {
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const engine = engineRef.current;
      if (!engine) return;

      if (e.code === 'Space' || e.code === 'Enter') {
        if (gameState === 'TITLE') {
          handlePlayGame();
          return;
        }
      }

      if (e.code === 'Escape' || e.code === 'KeyP') {
        if (gameState === 'PLAYING') {
          handlePause();
        } else if (gameState === 'PAUSED') {
          handleResume();
        }
        return;
      }

      if (gameState !== 'PLAYING') return;

      switch (e.code) {
        case 'ArrowLeft':
        case 'KeyA':
          engine.handleLeft();
          break;
        case 'ArrowRight':
        case 'KeyD':
          engine.handleRight();
          break;
        case 'ArrowUp':
        case 'KeyW':
        case 'Space':
          e.preventDefault();
          engine.handleJump();
          break;
        case 'ArrowDown':
        case 'KeyS':
          e.preventDefault();
          engine.handleSlide();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState]);

  // Touch Swipe Gesture Detection
  useEffect(() => {
    let touchStartX = 0;
    let touchStartY = 0;
    let touchStartTime = 0;

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
        touchStartTime = Date.now();
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      const engine = engineRef.current;
      if (!engine || gameState !== 'PLAYING') return;

      if (e.changedTouches.length > 0) {
        const dx = e.changedTouches[0].clientX - touchStartX;
        const dy = e.changedTouches[0].clientY - touchStartY;
        const dt = Date.now() - touchStartTime;

        const absDx = Math.abs(dx);
        const absDy = Math.abs(dy);

        // Minimum swipe distance
        if (absDx > 24 || absDy > 24) {
          if (absDx > absDy) {
            // Horizontal swipe
            if (dx > 0) {
              engine.handleRight();
            } else {
              engine.handleLeft();
            }
          } else {
            // Vertical swipe
            if (dy < 0) {
              engine.handleJump();
            } else {
              engine.handleSlide();
            }
          }
        }
      }
    };

    window.addEventListener('touchstart', handleTouchStart, { passive: true });
    window.addEventListener('touchend', handleTouchEnd, { passive: true });

    return () => {
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [gameState]);

  // Handlers
  const handlePlayGame = () => {
    sounds.playClick();
    if (engineRef.current) {
      engineRef.current.startGame();
      setGameState('PLAYING');
      setGameOverData(null);
    }
  };

  const handlePause = () => {
    sounds.playClick();
    if (engineRef.current) {
      engineRef.current.pauseGame();
      setGameState('PAUSED');
    }
  };

  const handleResume = () => {
    sounds.playClick();
    if (engineRef.current) {
      engineRef.current.resumeGame();
      setGameState('PLAYING');
    }
  };

  const handleRestart = () => {
    sounds.playClick();
    if (engineRef.current) {
      engineRef.current.startGame();
      setGameState('PLAYING');
      setGameOverData(null);
    }
  };

  const handleHome = () => {
    sounds.playClick();
    if (engineRef.current) {
      engineRef.current.returnToTitle();
      setGameState('TITLE');
      setGameOverData(null);
      setStats({ ...engineRef.current.stats });
    }
  };

  const handleSelectCharacter = (id: string) => {
    sounds.playClick();
    if (engineRef.current) {
      engineRef.current.selectCharacter(id);
      setStats({ ...engineRef.current.stats });
    }
    setIsCharModalOpen(false);
  };

  const handleUnlockCharacter = (char: CharacterConfig) => {
    if (stats.coins >= char.cost) {
      sounds.playGem();
      const updatedCoins = stats.coins - char.cost;
      const updatedUnlocked = [...stats.unlockedCharacters, char.id];
      const updatedStats: PlayerStats = {
        ...stats,
        coins: updatedCoins,
        unlockedCharacters: updatedUnlocked,
        selectedCharacter: char.id,
      };
      setStats(updatedStats);
      savePlayerStats(updatedStats);
      if (engineRef.current) {
        engineRef.current.stats = updatedStats;
        engineRef.current.selectCharacter(char.id);
      }
      try {
        confetti({ particleCount: 50, spread: 60 });
      } catch (e) {}
    }
  };

  const handleSelectWorld = (id: string) => {
    sounds.playClick();
    if (engineRef.current) {
      engineRef.current.selectWorld(id);
      setStats({ ...engineRef.current.stats });
    }
    setIsWorldModalOpen(false);
  };

  const handleUnlockWorld = (world: WorldConfig) => {
    if (stats.coins >= world.cost) {
      sounds.playGem();
      const updatedCoins = stats.coins - world.cost;
      const updatedUnlocked = [...stats.unlockedWorlds, world.id];
      const updatedStats: PlayerStats = {
        ...stats,
        coins: updatedCoins,
        unlockedWorlds: updatedUnlocked,
        selectedWorld: world.id,
      };
      setStats(updatedStats);
      savePlayerStats(updatedStats);
      if (engineRef.current) {
        engineRef.current.stats = updatedStats;
        engineRef.current.selectWorld(world.id);
      }
      try {
        confetti({ particleCount: 50, spread: 60 });
      } catch (e) {}
    }
  };

  const handleClaimDailyReward = () => {
    sounds.playClick();
    const amount = claimDailyReward();
    if (amount > 0) {
      sounds.playGem();
      const updatedCoins = stats.coins + amount;
      const updatedStats = { ...stats, coins: updatedCoins };
      setStats(updatedStats);
      savePlayerStats(updatedStats);
      if (engineRef.current) {
        engineRef.current.stats = updatedStats;
      }
      setDailyClaimToast(`Claimed +${amount} Gold Coins!`);
      setTimeout(() => setDailyClaimToast(null), 3500);
      try {
        confetti({ particleCount: 60, spread: 70 });
      } catch (e) {}
    }
  };

  const handleToggleSound = () => {
    const next = !stats.soundEnabled;
    sounds.setSoundEnabled(next);
    sounds.playClick();
    const updatedStats = { ...stats, soundEnabled: next };
    setStats(updatedStats);
    savePlayerStats(updatedStats);
  };

  const handleToggleMusic = () => {
    const next = !stats.musicEnabled;
    sounds.setMusicEnabled(next);
    sounds.playClick();
    const updatedStats = { ...stats, musicEnabled: next };
    setStats(updatedStats);
    savePlayerStats(updatedStats);
  };

  const handleToggleMobileControls = () => {
    sounds.playClick();
    const next = !stats.showMobileControls;
    const updatedStats = { ...stats, showMobileControls: next };
    setStats(updatedStats);
    savePlayerStats(updatedStats);
  };

  const currentWorld =
    WORLDS.find((w) => w.id === stats.selectedWorld) || WORLDS[0];
  const currentCharacter =
    CHARACTERS.find((c) => c.id === stats.selectedCharacter) || CHARACTERS[0];

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 select-none">
      {/* 3D WebGL Canvas Viewport */}
      <div
        ref={canvasContainerRef}
        className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing z-0"
      />

      {/* Daily Gift Toast Celebration Notification */}
      {dailyClaimToast && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-amber-400 to-yellow-300 text-amber-950 font-black text-sm md:text-base px-6 py-2.5 rounded-full shadow-2xl border-2 border-white animate-in slide-in-from-top duration-200">
          🎉 {dailyClaimToast}
        </div>
      )}

      {/* Title Screen View */}
      {gameState === 'TITLE' && (
        <TitleScreen
          stats={stats}
          currentWorld={currentWorld}
          currentCharacter={currentCharacter}
          missions={missions}
          onPlay={handlePlayGame}
          onOpenCharacters={() => setIsCharModalOpen(true)}
          onOpenWorlds={() => setIsWorldModalOpen(true)}
          onOpenMissions={() => setIsMissionsModalOpen(true)}
          onOpenSettings={() => setIsSettingsModalOpen(true)}
          onClaimDaily={handleClaimDailyReward}
          onOpenInstall={() => setIsInstallModalOpen(true)}
        />
      )}

      {/* In-Game HUD & Controls View */}
      {(gameState === 'PLAYING' || gameState === 'PAUSED') && (
        <GameHUD
          score={score}
          coins={coinsThisRun}
          distance={distance}
          powerUps={activePowerUps}
          isPaused={gameState === 'PAUSED'}
          showMobileControls={stats.showMobileControls}
          onPause={handlePause}
          onResume={handleResume}
          onRestart={handleRestart}
          onHome={handleHome}
          onMoveLeft={() => engineRef.current?.handleLeft()}
          onMoveRight={() => engineRef.current?.handleRight()}
          onJump={() => engineRef.current?.handleJump()}
          onSlide={() => engineRef.current?.handleSlide()}
        />
      )}

      {/* Game Over Modal */}
      {gameState === 'GAMEOVER' && gameOverData && (
        <GameOverModal
          score={gameOverData.score}
          coins={gameOverData.coins}
          distance={gameOverData.distance}
          isHighScore={gameOverData.isHighScore}
          bestScore={stats.highScore}
          onRestart={handleRestart}
          onHome={handleHome}
        />
      )}

      {/* Character Selection Modal */}
      {isCharModalOpen && (
        <CharacterSelectModal
          selectedId={stats.selectedCharacter}
          unlockedIds={stats.unlockedCharacters}
          coins={stats.coins}
          onSelect={handleSelectCharacter}
          onUnlock={handleUnlockCharacter}
          onClose={() => setIsCharModalOpen(false)}
        />
      )}

      {/* World Selection Modal */}
      {isWorldModalOpen && (
        <WorldSelectModal
          selectedId={stats.selectedWorld}
          unlockedIds={stats.unlockedWorlds}
          coins={stats.coins}
          onSelect={handleSelectWorld}
          onUnlock={handleUnlockWorld}
          onClose={() => setIsWorldModalOpen(false)}
        />
      )}

      {/* Missions Quests Modal */}
      {isMissionsModalOpen && (
        <MissionsModal
          missions={missions}
          onClose={() => setIsMissionsModalOpen(false)}
        />
      )}

      {/* Settings Modal */}
      {isSettingsModalOpen && (
        <SettingsModal
          soundEnabled={stats.soundEnabled}
          musicEnabled={stats.musicEnabled}
          showMobileControls={stats.showMobileControls}
          onToggleSound={handleToggleSound}
          onToggleMusic={handleToggleMusic}
          onToggleMobileControls={handleToggleMobileControls}
          onOpenInstall={() => setIsInstallModalOpen(true)}
          onClose={() => setIsSettingsModalOpen(false)}
        />
      )}

      {/* Android Phone Install Modal */}
      {isInstallModalOpen && (
        <InstallModal onClose={() => setIsInstallModalOpen(false)} />
      )}
    </div>
  );
}
